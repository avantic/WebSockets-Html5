Welcome to Kaazing WebSocket Gateway



=============================================================================

   Kaazing WebSocket Gateway is an HTML5-compliant WebSocket server, with
   emulation to support today's pre-HTML5 browsers.

Environment
=============================================================================

Java Requirements

    * Java Developer Kit (JDK) 1.6.0_14 (Java 6) or higher
    * The JAVA_HOME environment variable must be set to the directory where 
      the JDK is installed, for example C:\Program Files\Java\jdk1.6.0_14
    * Notes:
      * OpenJDK is not supported.
      * For information on installing JDK, see Oracle's Java SE documentation:
        http://download.oracle.com/javase/.

Operating System
    * Windows: Windows 7, Windows Vista, Windows XP SP3
    * Unix: Ubuntu Linux or any Unix or Linux platform that is certified
      with Java 1.6.0_14 (Java 6)


Starting Kaazing WebSocket Gateway
=============================================================================  

    To start Kaazing WebSocket Gateway, run the gateway.start command from the
    directory in which you have just unpacked the Kaazing WebSocket Gateway
    distribution, for example:
    C:\kaazing\kaazing-websocket-gateway-version-full\bin.

  View the Documentation

    If you downloaded, installed, and started the full version of Kaazing
    WebSocket Gateway, you can view the documentation and demos by visiting:

    http://localhost:8001/

    For detailed instructions on setting up the Gateway, see the document
    "Setting Up Kaazing WebSocket Gateway":

    http://localhost:8001/setup-guide.html

  Feedback

    Please contact us via email info@kaazing.com to provide your valuable
    feedback.

  Enjoy!

Licensing
=============================================================================

   This software is licensed under the terms you may find in the file
   named "LICENSE" in this directory.

   This distribution includes cryptographic software.  The country in
   which you currently reside may have restrictions on the import,
   possession, use, and/or re-export to another country, of
   encryption software.  BEFORE using any encryption software, please
   check your country's laws, regulations and policies concerning the
   import, possession, or use, and re-export of encryption software, to
   see if this is permitted.  See <http://www.wassenaar.org/> for more
   information.

   The U.S. Government Department of Commerce, Bureau of Industry and
   Security (BIS), has classified this software as Export Commodity
   Control Number (ECCN) 5D002.C.1, which includes information security
   software using or performing cryptographic functions with asymmetric
   algorithms.  The form and manner of this Apache Software Foundation
   distribution makes it eligible for export under the License Exception
   ENC Technology Software Unrestricted (TSU) exception (see the BIS
   Export Administration Regulations, Section 740.13) for both object
   code and source code.

   The following provides more details on the included cryptographic
   software:
  
   Kaazing WebSocket Gateway supports the use of SSL TCP connections
   when used with a JVM supporting the Java Cryptography extensions
   <http://java.sun.com/javase/technologies/security/>.

   Kaazing WebSocket Gateway does not include these libraries itself,
   but is designed to use them.
