/**
 * Copyright (c) 2007-2011, Kaazing Corporation. All rights reserved.
 * 
 * Licensed under the Kaazing Corporation Developer Agreement (2010-02-22), see:
 * 
 *   http://www.kaazing.com/license
 */

var browser=null;
if(typeof (ActiveXObject)!="undefined"){
browser="ie";
}else{
if(Object.prototype.toString.call(window.opera)=="[object Opera]"){
browser="opera";
}else{
if(navigator.vendor.indexOf("Apple")!=-1){
browser="safari";
}else{
if(navigator.vendor.indexOf("Google")!=-1){
if(navigator.userAgent.indexOf("Android")!=-1){
browser="android";
}else{
browser="chrome";
}
}else{
if(navigator.product=="Gecko"&&window.find&&!navigator.savePreferences){
browser="firefox";
}else{
throw new Error("couldn't detect browser");
}
}
}
}
}
switch(browser){
case "ie":
(function(){
if(document.createEvent===undefined){
var _1=function(){
};
_1.prototype.initEvent=function(_2,_3,_4){
this.type=_2;
this.bubbles=_3;
this.cancelable=_4;
};
document.createEvent=function(_5){
if(_5!="Events"){
throw new Error("Unsupported event name: "+_5);
}
return new _1();
};
}
document._w_3_c_d_o_m_e_v_e_n_t_s_createElement=document.createElement;
document.createElement=function(_6){
var _7=this._w_3_c_d_o_m_e_v_e_n_t_s_createElement(_6);
if(_7.addEventListener===undefined){
var _8={};
_7.addEventListener=function(_9,_a,_b){
_7.attachEvent("on"+_9,_a);
return addEventListener(_8,_9,_a,_b);
};
_7.removeEventListener=function(_c,_d,_e){
return removeEventListener(_8,_c,_d,_e);
};
_7.dispatchEvent=function(_f){
return dispatchEvent(_8,_f);
};
}
return _7;
};
if(window.addEventListener===undefined){
var _10=document.createElement("div");
var _11=(typeof (postMessage)==="undefined");
window.addEventListener=function(_12,_13,_14){
if(_11&&_12=="message"){
_10.addEventListener(_12,_13,_14);
}else{
window.attachEvent("on"+_12,_13);
}
};
window.removeEventListener=function(_15,_16,_17){
if(_11&&_15=="message"){
_10.removeEventListener(_15,_16,_17);
}else{
window.detachEvent("on"+_15,_16);
}
};
window.dispatchEvent=function(_18){
if(_11&&_18.type=="message"){
_10.dispatchEvent(_18);
}else{
window.fireEvent("on"+_18.type,_18);
}
};
}
function addEventListener(_19,_1a,_1b,_1c){
if(_1c){
throw new Error("Not implemented");
}
var _1d=_19[_1a]||{};
_19[_1a]=_1d;
_1d[_1b]=_1b;
};
function removeEventListener(_1e,_1f,_20,_21){
if(_21){
throw new Error("Not implemented");
}
var _22=_1e[_1f]||{};
delete _22[_20];
};
function dispatchEvent(_23,_24){
var _25=_24.type;
var _26=_23[_25]||{};
for(var key in _26){
if(typeof (_26[key])=="function"){
try{
_26[key](_24);
}
catch(e){
}
}
}
};
})();
break;
case "chrome":
case "android":
case "safari":
if(typeof (window.postMessage)==="undefined"&&typeof (window.dispatchEvent)==="undefined"&&typeof (document.dispatchEvent)==="function"){
window.dispatchEvent=function(_28){
document.dispatchEvent(_28);
};
var addEventListener0=window.addEventListener;
window.addEventListener=function(_29,_2a,_2b){
if(_29==="message"){
document.addEventListener(_29,_2a,_2b);
}else{
addEventListener0.call(window,_29,_2a,_2b);
}
};
var removeEventListener0=window.removeEventListener;
window.removeEventListener=function(_2c,_2d,_2e){
if(_2c==="message"){
document.removeEventListener(_2c,_2d,_2e);
}else{
removeEventListener0.call(window,_2c,_2d,_2e);
}
};
}
break;
case "opera":
var addEventListener0=window.addEventListener;
window.addEventListener=function(_2f,_30,_31){
var _32=_30;
if(_2f==="message"){
_32=function(_33){
if(_33.origin===undefined&&_33.uri!==undefined){
var uri=new URI(_33.uri);
delete uri.path;
delete uri.query;
delete uri.fragment;
_33.origin=uri.toString();
}
return _30(_33);
};
_30._$=_32;
}
addEventListener0.call(window,_2f,_32,_31);
};
var removeEventListener0=window.removeEventListener;
window.removeEventListener=function(_35,_36,_37){
var _38=_36;
if(_35==="message"){
_38=_36._$;
}
removeEventListener0.call(window,_35,_38,_37);
};
break;
}
function URI(str){
str=str||"";
var _3a=0;
var _3b=str.indexOf("://");
if(_3b!=-1){
this.scheme=str.slice(0,_3b);
_3a=_3b+3;
var _3c=str.indexOf("/",_3a);
if(_3c==-1){
_3c=str.length;
str+="/";
}
var _3d=str.slice(_3a,_3c);
this.authority=_3d;
_3a=_3c;
this.host=_3d;
var _3e=_3d.indexOf(":");
if(_3e!=-1){
this.host=_3d.slice(0,_3e);
this.port=parseInt(_3d.slice(_3e+1),10);
if(isNaN(this.port)){
throw new Error("Invalid URI syntax");
}
}
}
var _3f=str.indexOf("?",_3a);
if(_3f!=-1){
this.path=str.slice(_3a,_3f);
_3a=_3f+1;
}
var _40=str.indexOf("#",_3a);
if(_40!=-1){
if(_3f!=-1){
this.query=str.slice(_3a,_40);
}else{
this.path=str.slice(_3a,_40);
}
_3a=_40+1;
this.fragment=str.slice(_3a);
}else{
if(_3f!=-1){
this.query=str.slice(_3a);
}else{
this.path=str.slice(_3a);
}
}
};
(function(){
var _41=URI.prototype;
_41.toString=function(){
var sb=[];
var _43=this.scheme;
if(_43!==undefined){
sb.push(_43);
sb.push("://");
sb.push(this.host);
var _44=this.port;
if(_44!==undefined){
sb.push(":");
sb.push(_44.toString());
}
}
if(this.path!==undefined){
sb.push(this.path);
}
if(this.query!==undefined){
sb.push("?");
sb.push(this.query);
}
if(this.fragment!==undefined){
sb.push("#");
sb.push(this.fragment);
}
return sb.join("");
};
var _45={"http":80,"ws":80,"https":443,"wss":443};
})();
var postMessage0=(function(){
var _46=new URI((browser=="ie")?document.URL:location.href);
var _47={"http":80,"https":443};
if(_46.port==null){
_46.port=_47[_46.scheme];
_46.authority=_46.host+":"+_46.port;
}
var _48=_46.scheme+"://"+_46.authority;
var _49="/.kr";
if(typeof (postMessage)!=="undefined"){
return function(_4a,_4b,_4c){
if(typeof (_4b)!="string"){
throw new Error("Unsupported type. Messages must be strings");
}
switch(browser){
case "ie":
case "opera":
case "firefox":
setTimeout(function(){
_4a.postMessage(_4b,_4c);
},0);
break;
default:
_4a.postMessage(_4b,_4c);
break;
}
};
}else{
function MessagePipe(_4d){
this.sourceToken=toPaddedHex(Math.floor(Math.random()*(Math.pow(2,32)-1)),8);
this.iframe=_4d;
this.bridged=false;
this.lastWrite=0;
this.lastRead=0;
this.lastReadIndex=2;
this.lastSyn=0;
this.lastAck=0;
this.queue=[];
this.escapedFragments=[];
};
var _4e=MessagePipe.prototype;
_4e.attach=function(_4f,_50,_51,_52,_53,_54){
this.target=_4f;
this.targetOrigin=_50;
this.targetToken=_51;
this.reader=_52;
this.writer=_53;
this.writerURL=_54;
try{
this._lastHash=_52.location.hash;
this.poll=pollLocationHash;
}
catch(permissionDenied){
this._lastDocumentURL=_52.document.URL;
this.poll=pollDocumentURL;
}
if(_4f==parent){
dequeue(this,true);
}
};
_4e.detach=function(){
this.poll=function(){
};
delete this.target;
delete this.targetOrigin;
delete this.reader;
delete this.lastFragment;
delete this.writer;
delete this.writerURL;
};
_4e.poll=function(){
};
function pollLocationHash(){
var _55=this.reader.location.hash;
if(this._lastHash!=_55){
process(this,_55.substring(1));
this._lastHash=_55;
}
};
function pollDocumentURL(){
var _56=this.reader.document.URL;
if(this._lastDocumentURL!=_56){
var _57=_56.indexOf("#");
if(_57!=-1){
process(this,_56.substring(_57+1));
this._lastDocumentURL=_56;
}
}
};
_4e.post=function(_58,_59,_5a){
bridgeIfNecessary(this,_58);
var _5b=1000;
var _5c=escape(_59);
var _5d=[];
while(_5c.length>_5b){
var _5e=_5c.substring(0,_5b);
_5c=_5c.substring(_5b);
_5d.push(_5e);
}
_5d.push(_5c);
this.queue.push([_5a,_5d]);
if(this.writer!=null&&this.lastAck>=this.lastSyn){
dequeue(this,false);
}
};
function bridgeIfNecessary(_5f,_60){
if(_5f.lastWrite<1&&!_5f.bridged){
if(_60.parent==window){
var src=_5f.iframe.src;
var _62=src.split("#");
var _63=null;
var _64=document.getElementsByTagName("meta");
for(var i=0;i<_64.length;i++){
if(_64[i].name=="kaazing:resources"){
alert("kaazing:resources is no longer supported. Please refer to the Administrator's Guide section entitled \"Configuring a Web Server to Integrate with Kaazing Gateway\"");
}
}
var _66=_48;
var _67=_66.toString()+_49+"?.kr=xsp&.kv=10.05";
if(_63){
var _68=new URI(_66.toString());
var _62=_63.split(":");
_68.host=_62.shift();
if(_62.length){
_68.port=_62.shift();
}
_67=_68.toString()+_49+"?.kr=xsp&.kv=10.05";
}
for(var i=0;i<_64.length;i++){
if(_64[i].name=="kaazing:postMessageBridgeURL"){
var _69=_64[i].content;
var _6a=new URI(_69);
var _6b=new URI(location.toString());
if(!_6a.authority){
_6a.host=_6b.host;
_6a.port=_6b.port;
_6a.scheme=_6b.scheme;
if(_69.indexOf("/")!=0){
var _6c=_6b.path.split("/");
_6c.pop();
_6c.push(_69);
_6a.path=_6c.join("/");
}
}
postMessage0.BridgeURL=_6a.toString();
}
}
if(postMessage0.BridgeURL){
_67=postMessage0.BridgeURL;
}
var _6d=["I",_66,_5f.sourceToken,escape(_67)];
if(_62.length>1){
var _6e=_62[1];
_6d.push(escape(_6e));
}
_62[1]=_6d.join("!");
setTimeout(function(){
_60.location.replace(_62.join("#"));
},200);
_5f.bridged=true;
}
}
};
function flush(_6f,_70){
var _71=_6f.writerURL+"#"+_70;
_6f.writer.location.replace(_71);
};
function fromHex(_72){
return parseInt(_72,16);
};
function toPaddedHex(_73,_74){
var hex=_73.toString(16);
var _76=[];
_74-=hex.length;
while(_74-->0){
_76.push("0");
}
_76.push(hex);
return _76.join("");
};
function dequeue(_77,_78){
var _79=_77.queue;
var _7a=_77.lastRead;
if((_79.length>0||_78)&&_77.lastSyn>_77.lastAck){
var _7b=_77.lastFrames;
var _7c=_77.lastReadIndex;
if(fromHex(_7b[_7c])!=_7a){
_7b[_7c]=toPaddedHex(_7a,8);
flush(_77,_7b.join(""));
}
}else{
if(_79.length>0){
var _7d=_79.shift();
var _7e=_7d[0];
if(_7e=="*"||_7e==_77.targetOrigin){
_77.lastWrite++;
var _7f=_7d[1];
var _80=_7f.shift();
var _81=3;
var _7b=[_77.targetToken,toPaddedHex(_77.lastWrite,8),toPaddedHex(_7a,8),"F",toPaddedHex(_80.length,4),_80];
var _7c=2;
if(_7f.length>0){
_7b[_81]="f";
_77.queue.unshift(_7d);
}
if(_77.resendAck){
var _82=[_77.targetToken,toPaddedHex(_77.lastWrite-1,8),toPaddedHex(_7a,8),"a"];
_7b=_82.concat(_7b);
_7c+=_82.length;
}
flush(_77,_7b.join(""));
_77.lastFrames=_7b;
_77.lastReadIndex=_7c;
_77.lastSyn=_77.lastWrite;
_77.resendAck=false;
}
}else{
if(_78){
_77.lastWrite++;
var _7b=[_77.targetToken,toPaddedHex(_77.lastWrite,8),toPaddedHex(_7a,8),"a"];
var _7c=2;
if(_77.resendAck){
var _82=[_77.targetToken,toPaddedHex(_77.lastWrite-1,8),toPaddedHex(_7a,8),"a"];
_7b=_82.concat(_7b);
_7c+=_82.length;
}
flush(_77,_7b.join(""));
_77.lastFrames=_7b;
_77.lastReadIndex=_7c;
_77.resendAck=true;
}
}
}
};
function process(_83,_84){
var _85=_84.substring(0,8);
var _86=fromHex(_84.substring(8,16));
var _87=fromHex(_84.substring(16,24));
var _88=_84.charAt(24);
if(_85!=_83.sourceToken){
throw new Error("postMessage emulation tampering detected");
}
var _89=_83.lastRead;
var _8a=_89+1;
if(_86==_8a){
_83.lastRead=_8a;
}
if(_86==_8a||_86==_89){
_83.lastAck=_87;
}
if(_86==_8a||(_86==_89&&_88=="a")){
switch(_88){
case "f":
var _8b=_84.substr(29,fromHex(_84.substring(25,29)));
_83.escapedFragments.push(_8b);
dequeue(_83,true);
break;
case "F":
var _8c=_84.substr(29,fromHex(_84.substring(25,29)));
if(_83.escapedFragments!==undefined){
_83.escapedFragments.push(_8c);
_8c=_83.escapedFragments.join("");
_83.escapedFragments=[];
}
var _8d=unescape(_8c);
dispatch(_8d,_83.target,_83.targetOrigin);
dequeue(_83,true);
break;
case "a":
if(_84.length>25){
process(_83,_84.substring(25));
}else{
dequeue(_83,false);
}
break;
default:
throw new Error("unknown postMessage emulation payload type: "+_88);
}
}
};
function dispatch(_8e,_8f,_90){
var _91=document.createEvent("Events");
_91.initEvent("message",false,true);
_91.data=_8e;
_91.origin=_90;
_91.source=_8f;
dispatchEvent(_91);
};
var _92={};
var _93=[];
function pollReaders(){
for(var i=0,len=_93.length;i<len;i++){
var _96=_93[i];
_96.poll();
}
setTimeout(pollReaders,20);
};
function findMessagePipe(_97){
if(_97==parent){
return _92["parent"];
}else{
if(_97.parent==window){
var _98=document.getElementsByTagName("iframe");
for(var i=0;i<_98.length;i++){
var _9a=_98[i];
if(_97==_9a.contentWindow){
return supplyIFrameMessagePipe(_9a);
}
}
}else{
throw new Error("Generic peer postMessage not yet implemented");
}
}
};
function supplyIFrameMessagePipe(_9b){
var _9c=_9b._name;
if(_9c===undefined){
_9c="iframe$"+String(Math.random()).substring(2);
_9b._name=_9c;
}
var _9d=_92[_9c];
if(_9d===undefined){
_9d=new MessagePipe(_9b);
_92[_9c]=_9d;
}
return _9d;
};
function postMessage0(_9e,_9f,_a0){
if(typeof (_9f)!="string"){
throw new Error("Unsupported type. Messages must be strings");
}
if(_9e==window){
if(_a0=="*"||_a0==_48){
dispatch(_9f,window,_48);
}
}else{
var _a1=findMessagePipe(_9e);
_a1.post(_9e,_9f,_a0);
}
};
postMessage0.attach=function(_a2,_a3,_a4,_a5,_a6,_a7){
var _a8=findMessagePipe(_a2);
_a8.attach(_a2,_a3,_a4,_a5,_a6,_a7);
_93.push(_a8);
};
var _a9=function(_aa){
var _ab=new URI((browser=="ie")?document.URL:location.href);
var _ac;
var _ad={"http":80,"https":443};
if(_ab.port==null){
_ab.port=_ad[_ab.scheme];
_ab.authority=_ab.host+":"+_ab.port;
}
var _ae=unescape(_ab.fragment||"");
if(_ae.length>0){
var _af=_ae.split(",");
var _b0=_af.shift();
var _b1=_af.shift();
var _b2=_af.shift();
var _b3=_ab.scheme+"://"+document.domain+":"+_ab.port;
var _b4=_ab.scheme+"://"+_ab.authority;
var _b5=_b0+"/.kr?.kr=xsc&.kv=10.05";
var _b6=document.location.toString().split("#")[0];
var _b7=_b5+"#"+escape([_b3,_b1,escape(_b6)].join(","));
if(typeof (ActiveXObject)!="undefined"){
_ac=new ActiveXObject("htmlfile");
_ac.open();
try{
_ac.parentWindow.opener=window;
}
catch(domainError){
if(_aa){
_ac.domain=_aa;
}
_ac.parentWindow.opener=window;
}
_ac.write("<html>");
_ac.write("<body>");
if(_aa){
_ac.write("<script>CollectGarbage();document.domain='"+_aa+"';</"+"script>");
}
_ac.write("<iframe src=\""+_b5+"\"></iframe>");
_ac.write("</body>");
_ac.write("</html>");
_ac.close();
var _b8=_ac.body.lastChild;
var _b9=_ac.parentWindow;
var _ba=parent;
var _bb=_ba.parent.postMessage0;
if(typeof (_bb)!="undefined"){
_b8.onload=function(){
var _bc=_b8.contentWindow;
_bc.location.replace(_b7);
_bb.attach(_ba,_b0,_b2,_b9,_bc,_b5);
};
}
}else{
var _b8=document.createElement("iframe");
_b8.src=_b7;
document.body.appendChild(_b8);
var _b9=window;
var _bd=_b8.contentWindow;
var _ba=parent;
var _bb=_ba.parent.postMessage0;
if(typeof (_bb)!="undefined"){
_bb.attach(_ba,_b0,_b2,_b9,_bd,_b5);
}
}
}
window.onunload=function(){
try{
var _be=window.parent.parent.postMessage0;
if(typeof (_be)!="undefined"){
_be.detach(_ba);
}
}
catch(permissionDenied){
}
if(typeof (_ac)!=="undefined"){
_ac.parentWindow.opener=null;
_ac.open();
_ac.close();
_ac=null;
CollectGarbage();
}
};
};
postMessage0.__init__=function(_bf,_c0){
var _c1=_a9.toString();
_bf.URI=URI;
_bf.browser=browser;
if(!_c0){
_c0="";
}
_bf.setTimeout("("+_c1+")('"+_c0+"')",0);
};
postMessage0.bridgeURL=false;
postMessage0.detach=function(_c2){
var _c3=findMessagePipe(_c2);
for(var i=0;i<_93.length;i++){
if(_93[i]==_c3){
_93.splice(i,1);
}
}
_c3.detach();
};
if(window!=top){
_92["parent"]=new MessagePipe();
function initializeAsTargetIfNecessary(){
var _c5=new URI((browser=="ie")?document.URL:location.href);
var _c6=_c5.fragment||"";
if(document.body!=null&&_c6.length>0&&_c6.charAt(0)=="I"){
var _c7=unescape(_c6);
var _c8=_c7.split("!");
if(_c8.shift()=="I"){
var _c9=_c8.shift();
var _ca=_c8.shift();
var _cb=unescape(_c8.shift());
var _cc=_48;
if(_c9==_cc){
try{
parent.location.hash;
}
catch(permissionDenied){
document.domain=document.domain;
}
}
var _cd=_c8.shift()||"";
switch(browser){
case "firefox":
location.replace([location.href.split("#")[0],_cd].join("#"));
break;
default:
location.hash=_cd;
break;
}
var _ce=findMessagePipe(parent);
_ce.targetToken=_ca;
var _cf=_ce.sourceToken;
var _d0=_cb+"#"+escape([_cc,_ca,_cf].join(","));
var _d1;
_d1=document.createElement("iframe");
_d1.src=_d0;
_d1.style.position="absolute";
_d1.style.left="-10px";
_d1.style.top="10px";
_d1.style.visibility="hidden";
_d1.style.width="0px";
_d1.style.height="0px";
document.body.appendChild(_d1);
return;
}
}
setTimeout(initializeAsTargetIfNecessary,20);
};
initializeAsTargetIfNecessary();
}
var _d2=document.getElementsByTagName("meta");
for(var i=0;i<_d2.length;i++){
if(_d2[i].name==="kaazing:postMessage"){
if("immediate"==_d2[i].content){
var _d4=function(){
var _d5=document.getElementsByTagName("iframe");
for(var i=0;i<_d5.length;i++){
var _d7=_d5[i];
if(_d7.style["KaaPostMessage"]=="immediate"){
_d7.style["KaaPostMessage"]="none";
var _d8=supplyIFrameMessagePipe(_d7);
bridgeIfNecessary(_d8,_d7.contentWindow);
}
}
setTimeout(_d4,20);
};
setTimeout(_d4,20);
}
break;
}
}
for(var i=0;i<_d2.length;i++){
if(_d2[i].name==="kaazing:postMessagePrefix"){
var _d9=_d2[i].content;
if(_d9!=null&&_d9.length>0){
if(_d9.charAt(0)!="/"){
_d9="/"+_d9;
}
_49=_d9;
}
}
}
setTimeout(pollReaders,20);
return postMessage0;
}
})();
var XMLHttpRequest0=(function(){
var _da=new URI((browser=="ie")?document.URL:location.href);
var _db={"http":80,"https":443};
if(_da.port==null){
_da.port=_db[_da.scheme];
_da.authority=_da.host+":"+_da.port;
}
var _dc={};
var _dd={};
var _de=0;
function XMLHttpRequest0(){
if(browser=="firefox"&&typeof (Object.getPrototypeOf)=="function"){
var xhr=new XMLHttpRequest();
xhr.withCredentials=true;
return xhr;
}
};
var _e0=XMLHttpRequest0.prototype;
_e0.readyState=0;
_e0.responseText="";
_e0.status=0;
_e0.statusText="";
_e0.timeout=0;
_e0.onreadystatechange;
_e0.onerror;
_e0.onload;
_e0.onprogress;
_e0.open=function(_e1,_e2,_e3){
if(!_e3){
throw new Error("Asynchronous is required for cross-origin XMLHttpRequest emulation");
}
switch(this.readyState){
case 0:
case 4:
break;
default:
throw new Error("Invalid ready state");
}
if(_e2.indexOf(".kv=")==-1){
_e2+=((_e2.indexOf("?")==-1)?"?":"&")+".kv=10.05";
}else{
_e2=_e2.replace(/\.kv=[^&]*(.*)/,".kv=10.05$1");
}
var id=register(this);
var _e5=supplyPipe(this,_e2);
_e5.attach(id);
this._pipe=_e5;
this._requestHeaders=[];
this._method=_e1;
this._location=_e2;
this._responseHeaders=null;
this.readyState=1;
this.status=0;
this.statusText="";
this.responseText="";
var _e6=this;
setTimeout(function(){
_e6.readyState=1;
onreadystatechange(_e6);
},0);
};
_e0.setRequestHeader=function(_e7,_e8){
if(this.readyState!==1){
throw new Error("Invalid ready state");
}
this._requestHeaders.push([_e7,_e8]);
};
_e0.send=function(_e9){
if(this.readyState!==1){
throw new Error("Invalid ready state");
}
var _ea=this;
setTimeout(function(){
_ea.readyState=2;
onreadystatechange(_ea);
},0);
doSend(this,_e9);
};
_e0.abort=function(){
var _eb=this._pipe;
if(_eb!==undefined){
_eb.post(["a",this._id].join(""));
_eb.detach(this._id);
}
};
_e0.getResponseHeader=function(_ec){
if(this.status==0){
throw new Error("Invalid ready state");
}
var _ed=this._responseHeaders;
return _ed[_ec];
};
_e0.getAllResponseHeaders=function(){
if(this.status==0){
throw new Error("Invalid ready state");
}
return null;
};
function onreadystatechange(_ee){
if(typeof (_ee.onreadystatechange)!=="undefined"){
_ee.onreadystatechange();
}
switch(_ee.readyState){
case 3:
if(typeof (_ee.onprogress)!=="undefined"){
_ee.onprogress();
}
break;
case 4:
switch(Math.floor(_ee.status/100)){
case 0:
case 5:
if(typeof (_ee.onerror)!=="undefined"){
_ee.onerror();
}
break;
default:
if(typeof (_ee.onprogress)!=="undefined"){
_ee.onprogress();
}
if(typeof (_ee.onload)!=="undefined"){
_ee.onload();
}
break;
}
break;
}
};
function register(_ef){
var id=toPaddedHex(_de++,8);
_dd[id]=_ef;
_ef._id=id;
return id;
};
function doSend(_f1,_f2){
if(typeof (_f2)!=="string"){
_f2="";
}
var _f3=_f1._method.substring(0,10);
var _f4=_f1._location;
var _f5=_f1._requestHeaders;
var _f6=toPaddedHex(_f1.timeout,4);
var _f7=(_f1.onprogress!==undefined)?"t":"f";
var _f8=["s",_f1._id,_f3.length,_f3,toPaddedHex(_f4.length,4),_f4,toPaddedHex(_f5.length,4)];
for(var i=0;i<_f5.length;i++){
var _fa=_f5[i];
_f8.push(toPaddedHex(_fa[0].length,4));
_f8.push(_fa[0]);
_f8.push(toPaddedHex(_fa[1].length,4));
_f8.push(_fa[1]);
}
_f8.push(toPaddedHex(_f2.length,8),_f2,toPaddedHex(_f6,4),_f7);
_f1._pipe.post(_f8.join(""));
};
function supplyPipe(_fb,_fc){
var uri=new URI(_fc);
var _fe=(uri.scheme!=null&&uri.authority!=null);
var _ff=_fe?uri.scheme:_da.scheme;
var _100=_fe?uri.authority:_da.authority;
if(_100!=null&&uri.port==null){
_100=uri.host+":"+_db[_ff];
}
var _101=_ff+"://"+_100;
var pipe=_dc[_101];
if(pipe!==undefined){
if(!("iframe" in pipe&&"contentWindow" in pipe.iframe&&typeof pipe.iframe.contentWindow=="object")){
pipe=_dc[_101]=undefined;
}
}
if(pipe===undefined){
var _103=document.createElement("iframe");
_103.style.position="absolute";
_103.style.left="-10px";
_103.style.top="10px";
_103.style.visibility="hidden";
_103.style.width="0px";
_103.style.height="0px";
var _104=new URI(_101);
_104.query=".kr=xs&.kv=10.05";
_104.path="/";
_103.src=_104.toString();
function post(_105){
this.buffer.push(_105);
};
function attach(id){
var _107=this.attached[id];
if(_107===undefined){
_107={};
this.attached[id]=_107;
}
if(_107.timerID!==undefined){
clearTimeout(_107.timerID);
delete _107.timerID;
}
};
function detach(id){
var _109=this.attached[id];
if(_109!==undefined&&_109.timerID===undefined){
var _10a=this;
_109.timerID=setTimeout(function(){
delete _10a.attached[id];
var xhr=_dd[id];
if(xhr._pipe==pipe){
delete _dd[id];
delete xhr._id;
delete xhr._pipe;
}
postMessage0(pipe.iframe.contentWindow,["d",id].join(""),pipe.targetOrigin);
},10000);
}
};
pipe={"targetOrigin":_101,"iframe":_103,"buffer":[],"post":post,"attach":attach,"detach":detach,"attached":{count:0}};
_dc[_101]=pipe;
function sendInitWhenReady(){
var _10c=_103.contentWindow;
if(!_10c){
setTimeout(sendInitWhenReady,20);
}else{
postMessage0(_10c,"I",_101);
}
};
pipe.handshakeID=setTimeout(function(){
_dc[_101]=undefined;
pipe.post=function(_10d){
_fb.readyState=4;
_fb.status=0;
onreadystatechange(_fb);
};
if(pipe.buffer.length>0){
pipe.post();
}
},30000);
document.body.appendChild(_103);
sendInitWhenReady();
}
return pipe;
};
function onmessage(_10e){
var _10f=_10e.origin;
var _110={"http":":80","https":":443"};
var _111=_10f.split(":");
if(_111.length===2){
_10f+=_110[_111[0]];
}
var pipe=_dc[_10f];
if(pipe!==undefined&&pipe.iframe!==undefined&&_10e.source==pipe.iframe.contentWindow){
if(_10e.data=="I"){
clearTimeout(pipe.handshakeID);
var _113;
while((_113=pipe.buffer.shift())!==undefined){
postMessage0(pipe.iframe.contentWindow,_113,pipe.targetOrigin);
}
pipe.post=function(_114){
postMessage0(pipe.iframe.contentWindow,_114,pipe.targetOrigin);
};
}else{
var _113=_10e.data;
if(_113.length>=9){
var _115=0;
var type=_113.substring(_115,_115+=1);
var id=_113.substring(_115,_115+=8);
var _118=_dd[id];
if(_118!==undefined){
switch(type){
case "r":
var _119={};
var _11a=fromHex(_113.substring(_115,_115+=2));
for(var i=0;i<_11a;i++){
var _11c=fromHex(_113.substring(_115,_115+=4));
var _11d=_113.substring(_115,_115+=_11c);
var _11e=fromHex(_113.substring(_115,_115+=4));
var _11f=_113.substring(_115,_115+=_11e);
_119[_11d]=_11f;
}
var _120=fromHex(_113.substring(_115,_115+=4));
var _121=fromHex(_113.substring(_115,_115+=2));
var _122=_113.substring(_115,_115+=_121);
switch(_120){
case 301:
case 302:
case 307:
var _123=_119["Location"];
var id=register(_118);
var pipe=supplyPipe(_118,_123);
pipe.attach(id);
_118._pipe=pipe;
_118._method="GET";
_118._location=_123;
_118._redirect=true;
break;
default:
_118._responseHeaders=_119;
_118.status=_120;
_118.statusText=_122;
break;
}
break;
case "p":
var _124=parseInt(_113.substring(_115,_115+=1));
if(_118._id===id){
_118.readyState=_124;
var _125=fromHex(_113.substring(_115,_115+=8));
var _126=_113.substring(_115,_115+=_125);
if(_126.length>0){
_118.responseText+=_126;
}
onreadystatechange(_118);
}else{
if(_118._redirect){
_118._redirect=false;
doSend(_118,"");
}
}
if(_124==4){
pipe.detach(id);
}
break;
case "e":
if(_118._id===id){
_118.status=0;
_118.statusText="";
_118.readyState=4;
onreadystatechange(_118);
}
pipe.detach(id);
break;
case "t":
if(_118._id===id){
_118.status=0;
_118.statusText="";
_118.readyState=4;
if(typeof (_118.ontimeout)!=="undefined"){
_118.ontimeout();
}
}
pipe.detach(id);
break;
}
}
}
}
}else{
}
};
function fromHex(_127){
return parseInt(_127,16);
};
function toPaddedHex(_128,_129){
var hex=_128.toString(16);
var _12b=[];
_129-=hex.length;
while(_129-->0){
_12b.push("0");
}
_12b.push(hex);
return _12b.join("");
};
window.addEventListener("message",onmessage,false);
return XMLHttpRequest0;
})();
if(typeof (window.EventSource)==="undefined"){
var EventSource=(function(){
function EventSource(_12c){
this.lastEventId=null;
this.immediate=false;
this.retry=3000;
if(_12c.indexOf(".kv="==-1)){
_12c+=((_12c.indexOf("?")==-1)?"?":"&")+".kv=10.05";
}else{
_12c=_12c.replace(/\.kv=[^&]*(.*)/,".kv=10.05$1");
}
var _12d=new URI(_12c);
var _12e={"http":80,"https":443};
if(_12d.port==null){
_12d.port=_12e[_12d.scheme];
_12d.authority=_12d.host+":"+_12d.port;
}
this.origin=_12d.scheme+"://"+_12d.authority;
this.location=_12c;
this.lineQueue=[];
this.xhr=null;
this.reconnectTimer=null;
var _12f=this;
setTimeout(function(){
_connect(_12f,false);
},0);
};
var _130=EventSource.prototype;
_130.readyState=0;
_130.onopen=function(){
};
_130.onmessage=function(_131){
};
_130.onerror=function(){
};
_130.disconnect=function(){
if(this.readyState!==2){
_disconnect(this);
}
};
function _connect(_132,_133){
if(_132.reconnectTimer!==null){
_132.reconnectTimer=null;
}
var _134=new URI(_132.location);
var _135=[];
if(_132.lastEventId!==null){
_135.push(".ka="+this.lastEventId);
}
if(_132.location.indexOf("&.kb=")===-1&&_132.location.indexOf("?.kb=")===-1){
_135.push(".kb=512");
}
switch(browser){
case "ie":
case "safari":
_135.push(".kp=256");
break;
case "firefox":
_135.push(".kp=1025");
_135.push(String(Math.random()).substring(2));
break;
case "android":
_135.push(".kp=4096");
_135.push(".kbp=4096");
break;
}
if(_135.length>0){
if(_134.query===undefined){
_134.query=_135.join("&");
}else{
_134.query+="&"+_135.join("&");
}
}
var xhr=_132.xhr=new XMLHttpRequest0();
var _137={"xhr":xhr,"position":0};
if(_132.location.indexOf(".ki=p")==-1||_132.location.indexOf("https://")==0){
xhr.onprogress=function(){
setTimeout(function(){
_process(_132,_137);
},0);
};
}
xhr.onload=function(){
_process(_132,_137);
if(_132.xhr==_137.xhr&&_132.readyState!=2){
_reconnect(_132);
}
};
xhr.onerror=function(){
if(_132.readyState!=2){
_disconnect(_132);
_error(_132);
}
};
xhr.ontimeout=function(){
if(_132.readyState!=2){
_disconnect(_132);
_error(_132);
}
};
xhr.onreadystatechange=function(){
if(!_133){
if(xhr.readyState>=3){
_132.readyState=1;
if(typeof (_132.onopen)==="function"){
_132.onopen();
}
xhr.onreadystatechange=function(){
};
}
}
};
xhr.open("GET",_134.toString(),true);
xhr.send(null);
if(_132.location.indexOf("&.ki=p")==-1){
setTimeout(function(){
if(xhr.readyState<3&&_132.readyState<2){
_132.location+="&.ki=p";
_connect(_132,false);
}
},3000);
}
};
function _disconnect(_138){
if(_138.reconnectTimer!==null){
clearTimeout(_138.reconnectTimer);
_138.reconnectTimer=null;
}
if(_138.xhr!==null){
_138.xhr.onprogress=function(){
};
_138.xhr.onload=function(){
};
_138.xhr.onerror=function(){
};
_138.xhr.abort();
}
_138.lineQueue=[];
_138.lastEventId=null;
_138.location=null;
_138.readyState=2;
};
function _reconnect(_139){
_139.readyState=0;
if(_139.location!==null){
var _13a=_139.retry;
var _13b=_139.immediate;
if(_13b){
_139.immediate=false;
_13a=0;
}else{
_error(_139);
}
if(_139.readyState==0){
_139.reconnectTimer=setTimeout(function(){
_connect(_139,_13b);
},_13a);
}
}
};
var _13c=/[^\r\n]+|\r\n|\r|\n/g;
function _process(_13d,_13e){
var _13f=_13e.xhr.responseText;
var _140=_13f.slice(_13e.position);
var _141=_140.match(_13c)||[];
var _142=_13d.lineQueue;
var _143="";
while(_141.length>0){
var _144=_141.shift();
switch(_144.charAt(0)){
case "\r":
case "\n":
_13e.position+=_143.length+_144.length;
if(_143===""){
_dispatch(_13d);
}else{
_142.push(_143);
_143="";
}
break;
default:
_143=_144;
break;
}
}
};
function _dispatch(_145){
var data="";
var name="message";
var _148=_145.lineQueue;
while(_148.length>0){
var line=_148.shift();
var _14a=null;
var _14b="";
var _14c=line.indexOf(":");
if(_14c==-1){
_14a=line;
_14b="";
}else{
if(_14c===0){
continue;
}else{
_14a=line.slice(0,_14c);
var _14d=_14c+1;
if(line.charAt(_14d)==" "){
_14d++;
}
_14b=line.slice(_14d);
}
}
switch(_14a){
case "event":
name=_14b;
break;
case "id":
_145.lastEventId=_14b;
break;
case "retry":
_14b=parseInt(_14b,10);
if(!isNaN(_14b)){
_145.retry=_14b;
}
break;
case "data":
if(data.length>0){
data+="\n";
}
data+=_14b;
break;
case "location":
if(_14b!=""){
_145.location=_14b;
}
break;
case "reconnect":
_145.immediate=true;
break;
default:
break;
}
}
if(data.length>0||(name.length>0&&name!="message")){
var e=document.createEvent("Events");
e.initEvent(name,true,true);
e.lastEventId=_145.lastEventId;
e.data=data;
e.origin=_145.origin;
if(e.source!==null){
e.source=null;
}
if(typeof (_145.onmessage)==="function"){
_145.onmessage(e);
}
}
};
function _error(_14f){
var e=document.createEvent("Events");
e.initEvent("error",true,true);
if(typeof (_14f.onerror)==="function"){
_14f.onerror(e);
}
};
return EventSource;
})();
}else{
window.EventSource=(function(){
var _151={};
var _152={};
var _153=0;
function EventSource(_154){
this.readyState=0;
if(_154.indexOf(".kv=")==-1){
_154+=((_154.indexOf("?")==-1)?"?":"&")+".kv=10.05";
}else{
_154=_154.replace(/\.kv=[^&]*(.*)/,".kv=10.05$1");
}
var id=register(this);
var pipe=supplyPipe(this,_154);
pipe.attach(id);
var _157=["c",id,toPaddedHex(_154.length,4),_154].join("");
pipe.post(_157);
this._id=id;
this._pipe=pipe;
};
var _158=EventSource.prototype;
_158.disconnect=function(){
var pipe=this._pipe;
if(pipe!==undefined){
pipe.post(["a",this._id].join(""));
pipe.detach(this._id);
}
this.readyState=2;
};
function register(_15a){
var id=toPaddedHex(_153++,8);
_152[id]=_15a;
_15a._id=id;
return id;
};
function supplyPipe(_15c,_15d){
var uri=new URI(_15d);
var _15f=(uri.scheme!=null&&uri.authority!=null);
var _160=_15f?uri.scheme:locationURI.scheme;
var _161=_15f?uri.authority:locationURI.authority;
if(_161!=null&&uri.port==null){
_161=uri.host+":"+defaultPorts[_160];
}
var _162=_160+"://"+_161;
var pipe=_151[_162];
if(pipe===undefined){
var _164=document.createElement("iframe");
_164.style.position="absolute";
_164.style.left="-10px";
_164.style.top="10px";
_164.style.visibility="hidden";
_164.style.width="0px";
_164.style.height="0px";
var _165=new URI(_162);
_165.query=".kr=xse&.kv=10.05";
_165.path="/";
_164.src=_165.toString();
function post(_166){
this.buffer.push(_166);
};
function attach(id){
var _168=this.attached[id];
if(_168===undefined){
_168={};
this.attached[id]=_168;
}
if(_168.timerID!==undefined){
clearTimeout(_168.timerID);
delete _168.timerID;
}
};
function detach(id){
var _16a=this.attached[id];
if(_16a!==undefined&&_16a.timerID===undefined){
var _16b=this;
_16a.timerID=setTimeout(function(){
delete _16b.attached[id];
postMessage0(pipe.iframe.contentWindow,["d",id].join(""),pipe.targetOrigin);
},10000);
}
};
pipe={"targetOrigin":_162,"iframe":_164,"buffer":[],"post":post,"attach":attach,"detach":detach,"attached":{count:0}};
_151[_162]=pipe;
function sendInitWhenReady(){
var _16c=_164.contentWindow;
if(!_16c){
setTimeout(sendInitWhenReady,20);
}else{
postMessage0(_16c,"I",_162);
}
};
pipe.handshakeID=setTimeout(function(){
_151[_162]=undefined;
pipe.post=function(_16d){
_15c.readyState=4;
_15c.status=0;
onreadystatechange(_15c);
};
if(pipe.buffer.length>0){
pipe.post();
}
},30000);
document.body.appendChild(_164);
sendInitWhenReady();
}
return pipe;
};
function onmessage(_16e){
var _16f=_16e.origin;
var _170={"http":":80","https":":443"};
var _171=_16f.split(":");
if(_171.length===2){
_16f+=_170[_171[0]];
}
var pipe=_151[_16f];
if(pipe!==undefined&&pipe.iframe!==undefined&&_16e.source==pipe.iframe.contentWindow){
if(_16e.data=="I"){
clearTimeout(pipe.handshakeID);
var _173;
while((_173=pipe.buffer.shift())!==undefined){
postMessage0(pipe.iframe.contentWindow,_173,pipe.targetOrigin);
}
pipe.post=function(_174){
postMessage0(pipe.iframe.contentWindow,_174,pipe.targetOrigin);
};
}else{
var _173=_16e.data;
if(_173.length>=9){
var _175=0;
var type=_173.substring(_175,_175+=1);
var id=_173.substring(_175,_175+=8);
var _178=_152[id];
if(_178!==undefined){
switch(type){
case "D":
var _179=fromHex(_173.substring(_175,_175+=4));
var name=_173.substring(_175,_175+=_179);
var _17b=fromHex(_173.substring(_175,_175+=4));
var data=_173.substring(_175,_175+=_17b);
if(data.length>0||(name.length>0&&name!="message")){
var e=document.createEvent("Events");
e.initEvent(name,true,true);
e.lastEventId=_178.lastEventId;
e.data=data;
e.origin=_178.origin;
if(typeof (_178.onmessage)==="function"){
_178.onmessage(e);
}
}
break;
case "O":
_178.readyState=1;
_178.onopen();
break;
case "E":
if(_178._id===id){
_178.onerror();
}
break;
}
}
}
}
}else{
}
};
function fromHex(_17e){
return parseInt(_17e,16);
};
function toPaddedHex(_17f,_180){
var hex=_17f.toString(16);
var _182=[];
_180-=hex.length;
while(_180-->0){
_182.push("0");
}
_182.push(hex);
return _182.join("");
};
window.addEventListener("message",onmessage,false);
return EventSource;
})();
}
