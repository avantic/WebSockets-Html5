/**
 * Copyright (c) 2007-2011, Kaazing Corporation. All rights reserved.
 * 
 * Licensed under the Kaazing Corporation Developer Agreement (2010-02-22), see:
 * 
 *   http://www.kaazing.com/license
 */

var browser=null;
if(typeof (ActiveXObject)!="undefined"){
browser="ie";
}else{
if(Object.prototype.toString.call(window.opera)=="[object Opera]"){
browser="opera";
}else{
if(navigator.vendor.indexOf("Apple")!=-1){
browser="safari";
}else{
if(navigator.vendor.indexOf("Google")!=-1){
if(navigator.userAgent.indexOf("Android")!=-1){
browser="android";
}else{
browser="chrome";
}
}else{
if(navigator.product=="Gecko"&&window.find&&!navigator.savePreferences){
browser="firefox";
}else{
throw new Error("couldn't detect browser");
}
}
}
}
}
switch(browser){
case "ie":
(function(){
if(document.createEvent===undefined){
var _1=function(){
};
_1.prototype.initEvent=function(_2,_3,_4){
this.type=_2;
this.bubbles=_3;
this.cancelable=_4;
};
document.createEvent=function(_5){
if(_5!="Events"){
throw new Error("Unsupported event name: "+_5);
}
return new _1();
};
}
document._w_3_c_d_o_m_e_v_e_n_t_s_createElement=document.createElement;
document.createElement=function(_6){
var _7=this._w_3_c_d_o_m_e_v_e_n_t_s_createElement(_6);
if(_7.addEventListener===undefined){
var _8={};
_7.addEventListener=function(_9,_a,_b){
_7.attachEvent("on"+_9,_a);
return addEventListener(_8,_9,_a,_b);
};
_7.removeEventListener=function(_c,_d,_e){
return removeEventListener(_8,_c,_d,_e);
};
_7.dispatchEvent=function(_f){
return dispatchEvent(_8,_f);
};
}
return _7;
};
if(window.addEventListener===undefined){
var _10=document.createElement("div");
var _11=(typeof (postMessage)==="undefined");
window.addEventListener=function(_12,_13,_14){
if(_11&&_12=="message"){
_10.addEventListener(_12,_13,_14);
}else{
window.attachEvent("on"+_12,_13);
}
};
window.removeEventListener=function(_15,_16,_17){
if(_11&&_15=="message"){
_10.removeEventListener(_15,_16,_17);
}else{
window.detachEvent("on"+_15,_16);
}
};
window.dispatchEvent=function(_18){
if(_11&&_18.type=="message"){
_10.dispatchEvent(_18);
}else{
window.fireEvent("on"+_18.type,_18);
}
};
}
function addEventListener(_19,_1a,_1b,_1c){
if(_1c){
throw new Error("Not implemented");
}
var _1d=_19[_1a]||{};
_19[_1a]=_1d;
_1d[_1b]=_1b;
};
function removeEventListener(_1e,_1f,_20,_21){
if(_21){
throw new Error("Not implemented");
}
var _22=_1e[_1f]||{};
delete _22[_20];
};
function dispatchEvent(_23,_24){
var _25=_24.type;
var _26=_23[_25]||{};
for(var key in _26){
if(typeof (_26[key])=="function"){
try{
_26[key](_24);
}
catch(e){
}
}
}
};
})();
break;
case "chrome":
case "android":
case "safari":
if(typeof (window.postMessage)==="undefined"&&typeof (window.dispatchEvent)==="undefined"&&typeof (document.dispatchEvent)==="function"){
window.dispatchEvent=function(_28){
document.dispatchEvent(_28);
};
var addEventListener0=window.addEventListener;
window.addEventListener=function(_29,_2a,_2b){
if(_29==="message"){
document.addEventListener(_29,_2a,_2b);
}else{
addEventListener0.call(window,_29,_2a,_2b);
}
};
var removeEventListener0=window.removeEventListener;
window.removeEventListener=function(_2c,_2d,_2e){
if(_2c==="message"){
document.removeEventListener(_2c,_2d,_2e);
}else{
removeEventListener0.call(window,_2c,_2d,_2e);
}
};
}
break;
case "opera":
var addEventListener0=window.addEventListener;
window.addEventListener=function(_2f,_30,_31){
var _32=_30;
if(_2f==="message"){
_32=function(_33){
if(_33.origin===undefined&&_33.uri!==undefined){
var uri=new URI(_33.uri);
delete uri.path;
delete uri.query;
delete uri.fragment;
_33.origin=uri.toString();
}
return _30(_33);
};
_30._$=_32;
}
addEventListener0.call(window,_2f,_32,_31);
};
var removeEventListener0=window.removeEventListener;
window.removeEventListener=function(_35,_36,_37){
var _38=_36;
if(_35==="message"){
_38=_36._$;
}
removeEventListener0.call(window,_35,_38,_37);
};
break;
}
function URI(str){
str=str||"";
var _3a=0;
var _3b=str.indexOf("://");
if(_3b!=-1){
this.scheme=str.slice(0,_3b);
_3a=_3b+3;
var _3c=str.indexOf("/",_3a);
if(_3c==-1){
_3c=str.length;
str+="/";
}
var _3d=str.slice(_3a,_3c);
this.authority=_3d;
_3a=_3c;
this.host=_3d;
var _3e=_3d.indexOf(":");
if(_3e!=-1){
this.host=_3d.slice(0,_3e);
this.port=parseInt(_3d.slice(_3e+1),10);
if(isNaN(this.port)){
throw new Error("Invalid URI syntax");
}
}
}
var _3f=str.indexOf("?",_3a);
if(_3f!=-1){
this.path=str.slice(_3a,_3f);
_3a=_3f+1;
}
var _40=str.indexOf("#",_3a);
if(_40!=-1){
if(_3f!=-1){
this.query=str.slice(_3a,_40);
}else{
this.path=str.slice(_3a,_40);
}
_3a=_40+1;
this.fragment=str.slice(_3a);
}else{
if(_3f!=-1){
this.query=str.slice(_3a);
}else{
this.path=str.slice(_3a);
}
}
};
(function(){
var _41=URI.prototype;
_41.toString=function(){
var sb=[];
var _43=this.scheme;
if(_43!==undefined){
sb.push(_43);
sb.push("://");
sb.push(this.host);
var _44=this.port;
if(_44!==undefined){
sb.push(":");
sb.push(_44.toString());
}
}
if(this.path!==undefined){
sb.push(this.path);
}
if(this.query!==undefined){
sb.push("?");
sb.push(this.query);
}
if(this.fragment!==undefined){
sb.push("#");
sb.push(this.fragment);
}
return sb.join("");
};
var _45={"http":80,"ws":80,"https":443,"wss":443};
})();
var postMessage0=(function(){
var _46=new URI((browser=="ie")?document.URL:location.href);
var _47={"http":80,"https":443};
if(_46.port==null){
_46.port=_47[_46.scheme];
_46.authority=_46.host+":"+_46.port;
}
var _48=_46.scheme+"://"+_46.authority;
var _49="/.kr";
if(typeof (postMessage)!=="undefined"){
return function(_4a,_4b,_4c){
if(typeof (_4b)!="string"){
throw new Error("Unsupported type. Messages must be strings");
}
switch(browser){
case "ie":
case "opera":
case "firefox":
setTimeout(function(){
_4a.postMessage(_4b,_4c);
},0);
break;
default:
_4a.postMessage(_4b,_4c);
break;
}
};
}else{
function MessagePipe(_4d){
this.sourceToken=toPaddedHex(Math.floor(Math.random()*(Math.pow(2,32)-1)),8);
this.iframe=_4d;
this.bridged=false;
this.lastWrite=0;
this.lastRead=0;
this.lastReadIndex=2;
this.lastSyn=0;
this.lastAck=0;
this.queue=[];
this.escapedFragments=[];
};
var _4e=MessagePipe.prototype;
_4e.attach=function(_4f,_50,_51,_52,_53,_54){
this.target=_4f;
this.targetOrigin=_50;
this.targetToken=_51;
this.reader=_52;
this.writer=_53;
this.writerURL=_54;
try{
this._lastHash=_52.location.hash;
this.poll=pollLocationHash;
}
catch(permissionDenied){
this._lastDocumentURL=_52.document.URL;
this.poll=pollDocumentURL;
}
if(_4f==parent){
dequeue(this,true);
}
};
_4e.detach=function(){
this.poll=function(){
};
delete this.target;
delete this.targetOrigin;
delete this.reader;
delete this.lastFragment;
delete this.writer;
delete this.writerURL;
};
_4e.poll=function(){
};
function pollLocationHash(){
var _55=this.reader.location.hash;
if(this._lastHash!=_55){
process(this,_55.substring(1));
this._lastHash=_55;
}
};
function pollDocumentURL(){
var _56=this.reader.document.URL;
if(this._lastDocumentURL!=_56){
var _57=_56.indexOf("#");
if(_57!=-1){
process(this,_56.substring(_57+1));
this._lastDocumentURL=_56;
}
}
};
_4e.post=function(_58,_59,_5a){
bridgeIfNecessary(this,_58);
var _5b=1000;
var _5c=escape(_59);
var _5d=[];
while(_5c.length>_5b){
var _5e=_5c.substring(0,_5b);
_5c=_5c.substring(_5b);
_5d.push(_5e);
}
_5d.push(_5c);
this.queue.push([_5a,_5d]);
if(this.writer!=null&&this.lastAck>=this.lastSyn){
dequeue(this,false);
}
};
function bridgeIfNecessary(_5f,_60){
if(_5f.lastWrite<1&&!_5f.bridged){
if(_60.parent==window){
var src=_5f.iframe.src;
var _62=src.split("#");
var _63=null;
var _64=document.getElementsByTagName("meta");
for(var i=0;i<_64.length;i++){
if(_64[i].name=="kaazing:resources"){
alert("kaazing:resources is no longer supported. Please refer to the Administrator's Guide section entitled \"Configuring a Web Server to Integrate with Kaazing Gateway\"");
}
}
var _66=_48;
var _67=_66.toString()+_49+"?.kr=xsp&.kv=10.05";
if(_63){
var _68=new URI(_66.toString());
var _62=_63.split(":");
_68.host=_62.shift();
if(_62.length){
_68.port=_62.shift();
}
_67=_68.toString()+_49+"?.kr=xsp&.kv=10.05";
}
for(var i=0;i<_64.length;i++){
if(_64[i].name=="kaazing:postMessageBridgeURL"){
var _69=_64[i].content;
var _6a=new URI(_69);
var _6b=new URI(location.toString());
if(!_6a.authority){
_6a.host=_6b.host;
_6a.port=_6b.port;
_6a.scheme=_6b.scheme;
if(_69.indexOf("/")!=0){
var _6c=_6b.path.split("/");
_6c.pop();
_6c.push(_69);
_6a.path=_6c.join("/");
}
}
postMessage0.BridgeURL=_6a.toString();
}
}
if(postMessage0.BridgeURL){
_67=postMessage0.BridgeURL;
}
var _6d=["I",_66,_5f.sourceToken,escape(_67)];
if(_62.length>1){
var _6e=_62[1];
_6d.push(escape(_6e));
}
_62[1]=_6d.join("!");
setTimeout(function(){
_60.location.replace(_62.join("#"));
},200);
_5f.bridged=true;
}
}
};
function flush(_6f,_70){
var _71=_6f.writerURL+"#"+_70;
_6f.writer.location.replace(_71);
};
function fromHex(_72){
return parseInt(_72,16);
};
function toPaddedHex(_73,_74){
var hex=_73.toString(16);
var _76=[];
_74-=hex.length;
while(_74-->0){
_76.push("0");
}
_76.push(hex);
return _76.join("");
};
function dequeue(_77,_78){
var _79=_77.queue;
var _7a=_77.lastRead;
if((_79.length>0||_78)&&_77.lastSyn>_77.lastAck){
var _7b=_77.lastFrames;
var _7c=_77.lastReadIndex;
if(fromHex(_7b[_7c])!=_7a){
_7b[_7c]=toPaddedHex(_7a,8);
flush(_77,_7b.join(""));
}
}else{
if(_79.length>0){
var _7d=_79.shift();
var _7e=_7d[0];
if(_7e=="*"||_7e==_77.targetOrigin){
_77.lastWrite++;
var _7f=_7d[1];
var _80=_7f.shift();
var _81=3;
var _7b=[_77.targetToken,toPaddedHex(_77.lastWrite,8),toPaddedHex(_7a,8),"F",toPaddedHex(_80.length,4),_80];
var _7c=2;
if(_7f.length>0){
_7b[_81]="f";
_77.queue.unshift(_7d);
}
if(_77.resendAck){
var _82=[_77.targetToken,toPaddedHex(_77.lastWrite-1,8),toPaddedHex(_7a,8),"a"];
_7b=_82.concat(_7b);
_7c+=_82.length;
}
flush(_77,_7b.join(""));
_77.lastFrames=_7b;
_77.lastReadIndex=_7c;
_77.lastSyn=_77.lastWrite;
_77.resendAck=false;
}
}else{
if(_78){
_77.lastWrite++;
var _7b=[_77.targetToken,toPaddedHex(_77.lastWrite,8),toPaddedHex(_7a,8),"a"];
var _7c=2;
if(_77.resendAck){
var _82=[_77.targetToken,toPaddedHex(_77.lastWrite-1,8),toPaddedHex(_7a,8),"a"];
_7b=_82.concat(_7b);
_7c+=_82.length;
}
flush(_77,_7b.join(""));
_77.lastFrames=_7b;
_77.lastReadIndex=_7c;
_77.resendAck=true;
}
}
}
};
function process(_83,_84){
var _85=_84.substring(0,8);
var _86=fromHex(_84.substring(8,16));
var _87=fromHex(_84.substring(16,24));
var _88=_84.charAt(24);
if(_85!=_83.sourceToken){
throw new Error("postMessage emulation tampering detected");
}
var _89=_83.lastRead;
var _8a=_89+1;
if(_86==_8a){
_83.lastRead=_8a;
}
if(_86==_8a||_86==_89){
_83.lastAck=_87;
}
if(_86==_8a||(_86==_89&&_88=="a")){
switch(_88){
case "f":
var _8b=_84.substr(29,fromHex(_84.substring(25,29)));
_83.escapedFragments.push(_8b);
dequeue(_83,true);
break;
case "F":
var _8c=_84.substr(29,fromHex(_84.substring(25,29)));
if(_83.escapedFragments!==undefined){
_83.escapedFragments.push(_8c);
_8c=_83.escapedFragments.join("");
_83.escapedFragments=[];
}
var _8d=unescape(_8c);
dispatch(_8d,_83.target,_83.targetOrigin);
dequeue(_83,true);
break;
case "a":
if(_84.length>25){
process(_83,_84.substring(25));
}else{
dequeue(_83,false);
}
break;
default:
throw new Error("unknown postMessage emulation payload type: "+_88);
}
}
};
function dispatch(_8e,_8f,_90){
var _91=document.createEvent("Events");
_91.initEvent("message",false,true);
_91.data=_8e;
_91.origin=_90;
_91.source=_8f;
dispatchEvent(_91);
};
var _92={};
var _93=[];
function pollReaders(){
for(var i=0,len=_93.length;i<len;i++){
var _96=_93[i];
_96.poll();
}
setTimeout(pollReaders,20);
};
function findMessagePipe(_97){
if(_97==parent){
return _92["parent"];
}else{
if(_97.parent==window){
var _98=document.getElementsByTagName("iframe");
for(var i=0;i<_98.length;i++){
var _9a=_98[i];
if(_97==_9a.contentWindow){
return supplyIFrameMessagePipe(_9a);
}
}
}else{
throw new Error("Generic peer postMessage not yet implemented");
}
}
};
function supplyIFrameMessagePipe(_9b){
var _9c=_9b._name;
if(_9c===undefined){
_9c="iframe$"+String(Math.random()).substring(2);
_9b._name=_9c;
}
var _9d=_92[_9c];
if(_9d===undefined){
_9d=new MessagePipe(_9b);
_92[_9c]=_9d;
}
return _9d;
};
function postMessage0(_9e,_9f,_a0){
if(typeof (_9f)!="string"){
throw new Error("Unsupported type. Messages must be strings");
}
if(_9e==window){
if(_a0=="*"||_a0==_48){
dispatch(_9f,window,_48);
}
}else{
var _a1=findMessagePipe(_9e);
_a1.post(_9e,_9f,_a0);
}
};
postMessage0.attach=function(_a2,_a3,_a4,_a5,_a6,_a7){
var _a8=findMessagePipe(_a2);
_a8.attach(_a2,_a3,_a4,_a5,_a6,_a7);
_93.push(_a8);
};
var _a9=function(_aa){
var _ab=new URI((browser=="ie")?document.URL:location.href);
var _ac;
var _ad={"http":80,"https":443};
if(_ab.port==null){
_ab.port=_ad[_ab.scheme];
_ab.authority=_ab.host+":"+_ab.port;
}
var _ae=unescape(_ab.fragment||"");
if(_ae.length>0){
var _af=_ae.split(",");
var _b0=_af.shift();
var _b1=_af.shift();
var _b2=_af.shift();
var _b3=_ab.scheme+"://"+document.domain+":"+_ab.port;
var _b4=_ab.scheme+"://"+_ab.authority;
var _b5=_b0+"/.kr?.kr=xsc&.kv=10.05";
var _b6=document.location.toString().split("#")[0];
var _b7=_b5+"#"+escape([_b3,_b1,escape(_b6)].join(","));
if(typeof (ActiveXObject)!="undefined"){
_ac=new ActiveXObject("htmlfile");
_ac.open();
try{
_ac.parentWindow.opener=window;
}
catch(domainError){
if(_aa){
_ac.domain=_aa;
}
_ac.parentWindow.opener=window;
}
_ac.write("<html>");
_ac.write("<body>");
if(_aa){
_ac.write("<script>CollectGarbage();document.domain='"+_aa+"';</"+"script>");
}
_ac.write("<iframe src=\""+_b5+"\"></iframe>");
_ac.write("</body>");
_ac.write("</html>");
_ac.close();
var _b8=_ac.body.lastChild;
var _b9=_ac.parentWindow;
var _ba=parent;
var _bb=_ba.parent.postMessage0;
if(typeof (_bb)!="undefined"){
_b8.onload=function(){
var _bc=_b8.contentWindow;
_bc.location.replace(_b7);
_bb.attach(_ba,_b0,_b2,_b9,_bc,_b5);
};
}
}else{
var _b8=document.createElement("iframe");
_b8.src=_b7;
document.body.appendChild(_b8);
var _b9=window;
var _bd=_b8.contentWindow;
var _ba=parent;
var _bb=_ba.parent.postMessage0;
if(typeof (_bb)!="undefined"){
_bb.attach(_ba,_b0,_b2,_b9,_bd,_b5);
}
}
}
window.onunload=function(){
try{
var _be=window.parent.parent.postMessage0;
if(typeof (_be)!="undefined"){
_be.detach(_ba);
}
}
catch(permissionDenied){
}
if(typeof (_ac)!=="undefined"){
_ac.parentWindow.opener=null;
_ac.open();
_ac.close();
_ac=null;
CollectGarbage();
}
};
};
postMessage0.__init__=function(_bf,_c0){
var _c1=_a9.toString();
_bf.URI=URI;
_bf.browser=browser;
if(!_c0){
_c0="";
}
_bf.setTimeout("("+_c1+")('"+_c0+"')",0);
};
postMessage0.bridgeURL=false;
postMessage0.detach=function(_c2){
var _c3=findMessagePipe(_c2);
for(var i=0;i<_93.length;i++){
if(_93[i]==_c3){
_93.splice(i,1);
}
}
_c3.detach();
};
if(window!=top){
_92["parent"]=new MessagePipe();
function initializeAsTargetIfNecessary(){
var _c5=new URI((browser=="ie")?document.URL:location.href);
var _c6=_c5.fragment||"";
if(document.body!=null&&_c6.length>0&&_c6.charAt(0)=="I"){
var _c7=unescape(_c6);
var _c8=_c7.split("!");
if(_c8.shift()=="I"){
var _c9=_c8.shift();
var _ca=_c8.shift();
var _cb=unescape(_c8.shift());
var _cc=_48;
if(_c9==_cc){
try{
parent.location.hash;
}
catch(permissionDenied){
document.domain=document.domain;
}
}
var _cd=_c8.shift()||"";
switch(browser){
case "firefox":
location.replace([location.href.split("#")[0],_cd].join("#"));
break;
default:
location.hash=_cd;
break;
}
var _ce=findMessagePipe(parent);
_ce.targetToken=_ca;
var _cf=_ce.sourceToken;
var _d0=_cb+"#"+escape([_cc,_ca,_cf].join(","));
var _d1;
_d1=document.createElement("iframe");
_d1.src=_d0;
_d1.style.position="absolute";
_d1.style.left="-10px";
_d1.style.top="10px";
_d1.style.visibility="hidden";
_d1.style.width="0px";
_d1.style.height="0px";
document.body.appendChild(_d1);
return;
}
}
setTimeout(initializeAsTargetIfNecessary,20);
};
initializeAsTargetIfNecessary();
}
var _d2=document.getElementsByTagName("meta");
for(var i=0;i<_d2.length;i++){
if(_d2[i].name==="kaazing:postMessage"){
if("immediate"==_d2[i].content){
var _d4=function(){
var _d5=document.getElementsByTagName("iframe");
for(var i=0;i<_d5.length;i++){
var _d7=_d5[i];
if(_d7.style["KaaPostMessage"]=="immediate"){
_d7.style["KaaPostMessage"]="none";
var _d8=supplyIFrameMessagePipe(_d7);
bridgeIfNecessary(_d8,_d7.contentWindow);
}
}
setTimeout(_d4,20);
};
setTimeout(_d4,20);
}
break;
}
}
for(var i=0;i<_d2.length;i++){
if(_d2[i].name==="kaazing:postMessagePrefix"){
var _d9=_d2[i].content;
if(_d9!=null&&_d9.length>0){
if(_d9.charAt(0)!="/"){
_d9="/"+_d9;
}
_49=_d9;
}
}
}
setTimeout(pollReaders,20);
return postMessage0;
}
})();
