/**
 * Copyright (c) 2007-2011, Kaazing Corporation. All rights reserved.
 * 
 * Licensed under the Kaazing Corporation Developer Agreement (2010-02-22), see:
 * 
 *   http://www.kaazing.com/license
 */

(function(){
var _1=function(_2){
var _3=[];
for(var _4 in _2){
if(typeof (_4)=="string"){
var _5=_2[_4];
if(typeof (_5)=="string"){
_3.push("["+_6(_4)+","+_6(_5)+"]");
}
}
}
return "["+_3.join(",")+"]";
};
var _6=function(o){
return "'"+o.replace(/([\'\\])/g,"\\$1")+"'";
};
var _8=function(_9,_a){
if(_a!==null){
var _b=eval(_a);
if(_b!==null&&_b!==undefined){
for(var j=0;j<_b.length;j++){
var _d=_b[j];
_9[_d[0]]=_d[1];
}
}
}
};
var _e=function(_f){
var _10=document.cookie.split(";");
for(var i=0;i<_10.length;i++){
var _12=_10[i].split("=");
if(new RegExp("\\s*"+_f+"\\s*").test(_12[0])){
return _12[1];
}
}
return undefined;
};
var _13=function(_14,_15,_16){
document.cookie=_14+"="+_16+_15;
};
var _17=function(_18,_19){
document.cookie=_18+"=[]"+_19+";expires=Thu, 01-Jan-1970 00:00:01 GMT";
};
if(document.sessionStorage===undefined){
if(window.sessionStorage!==undefined){
document.sessionStorage=window.sessionStorage;
}else{
var _1a="KZSTORAGE"+location.port;
var _1b=";domain="+location.hostname;
if("https:"===location.protocol){
_1b+=";secure";
}
window.addEventListener("load",function(){
var _1c=_e(_1a);
if(_1c!==undefined){
_8(document.sessionStorage,_1c);
_17(_1a,_1b);
}
},false);
window.addEventListener("unload",function(){
var _1d=_1(document.sessionStorage);
_13(_1a,_1b,_1d);
},false);
document.sessionStorage={};
}
}
if(document.localStorage===undefined){
var _1e="KZLOCAL"+location.port;
document.localStorage={};
var _1f;
var _20;
var _21;
switch(browser){
case "ie":
var _22=document.createElement("<span>");
window.attachEvent("onload",function(){
document.body.appendChild(_22);
_22.addBehavior("#default#userData");
_23();
},false);
_1f=function(_24){
_22.setAttribute(_1e,_24);
_22.save("/localStorage");
};
_20=function(){
_22.load("/localStorage");
return _22.getAttribute(_1e);
};
_21=function(){
_22.removeAttribute(_1e);
_22.save("/localStorage");
};
break;
default:
var _25;
if(window.globalStorage!==undefined){
try{
_25=window.globalStorage[location.hostname];
}
catch(e){
}
}
if(_25!==undefined){
_1f=function(_26){
_25[_1e]=_26;
};
_20=function(){
var _27=_25[_1e];
return _27?_27.value:undefined;
};
_21=function(){
delete _25[_1e];
};
}else{
var _1b=";domain="+location.hostname+";expires="+new Date(new Date().getTime()+315360000000).toGMTString();
if("https:"===location.protocol){
_1b+=";secure";
}
_1f=function(_28){
_13(_1e,_1b,_28);
};
_20=function(){
return _e(_1e);
};
_21=function(){
_17(_1e,_1b);
};
}
window.addEventListener("load",function(){
_23();
},false);
break;
}
var _29=function(_2a,_2b){
var _2c=_20();
if(_2c!==_2b){
_8(_2a,_2c);
}
return _2c;
};
var _2d=function(_2e,_2f){
var _30=_1(document.localStorage);
if(_30!==_2f){
if(_30=="{}"){
_21();
}else{
_1f(_30);
}
}
return _30;
};
var _31;
var _32;
var _23=function(){
_31=_29(document.localStorage,_31);
_32=_2d(document.localStorage,_32||_31);
setTimeout(_23,1000);
};
}
})();
Keyring=(function(){
function Keyring(_33){
this._location=_33;
this._xhrs=[];
this._keys={};
};
var _34=Keyring.prototype;
_34.onlogin=function(_35){
};
_34.onlogout=function(){
};
_34.login=function(_36){
var _37=this;
var xhr=this._getXHR("renew");
xhr.open("POST",this._location,true);
if(_36!==undefined){
var _39=btoa("Basic "+(_36.username||"")+":"+(_36.password||""));
xhr.setRequestHeader("Authorization",_39);
}
xhr.onreadystatechange=function(){
if(xhr.readyState==4){
switch(xhr.status){
case 200:
_37.onlogin(true);
_3a(_37,xhr);
break;
default:
_37.onlogin(false);
break;
}
}
};
xhr.send("RENEW\n\n");
};
_34.logout=function(){
clearTimer(this);
var _3b=this;
var xhr=this._getXHR("renew");
xhr.open("POST",this._location);
xhr.onreadystatechange=function(){
if(xhr.readyState==4&&xhr.status==200){
_3b.onlogout();
}
};
xhr.send("RELEASE\n\n");
};
_34.findKey=function(_3d){
return this._keys[_3d];
};
_34._getXHR=function(_3e){
var _3f=this._xhrs;
if(_3f[_3e]===undefined){
_3f[_3e]=new XMLHttpRequest0();
}
return _3f[_3e];
};
var _40=function(_41){
if(_41._timerID!==undefined){
clearTimeout(_41._timerID);
_41._timerID=null;
}
};
var _42=function(_43,_44,_45){
_40(_43);
_43._timerID=setTimeout(_44,_45);
};
var _3a=function(_46,xhr){
var _48=xhr.responseText.split("\n");
if(_48[0]=="RENEWED"){
var _49=_48[1].split(":");
if(_49[0]=="max-age"){
var _4a=parseInt(_49[1]);
_42(_46,function(){
xhr.open(this._location);
xhr.onreadystatechange=function(){
if(xhr.readyState==4&&xhr.status==200){
_3a(_46,xhr);
}
};
xhr.send("RENEW\n\n");
},_4a*500);
}
}
};
return Keyring;
})();
function Key(){
};
(function(){
var _4b=Key.prototype;
_4b.purge=function(){
};
_4b.resolve=function(_4c){
};
})();
EncryptedKeyring=(function(){
function EncryptedKeyring(_4d,_4e){
Keyring.call(this,_4e);
this._storage=_4d;
};
var _4f=EncryptedKeyring.prototype=new Keyring();
_4f.createKey=function(_50,_51){
var _52=this;
var _53=_52._storage;
var _54="encrypted."+_50;
var key=new Key();
key.resolve=function(_56){
var _57=(_53[_54]||"").toString();
if(_57!==""){
_authorize(_52,_57,_50,_56);
}else{
(_51||_singleSignOn)(function(_58){
_sealAndAuthorize(_52,_58.username+"|"+_58.password,_54,_50,_56);
},_50);
}
};
key.purge=function(){
_53[_54]="";
};
this._keys[_50]=key;
return key;
};
_4f.destroyKey=function(_59){
this._keys[_59]=undefined;
};
function _authorize(_5a,_5b,_5c,_5d){
var _5e=[];
_5e.push("value:"+_5b);
_5e.push("service:"+_5c);
_5e.push("timeout:30");
_5e.push("");
var _5f=[];
_5f.push("AUTHORIZE");
_5f.push(_5e.join("\n"));
_5f.push("");
var xhr=_5a._getXHR("resolve");
xhr.open("POST",_5a._location,true);
xhr.onreadystatechange=function(){
if(xhr.readyState==4&&xhr.status==200){
var _61=xhr.responseText.split("\n");
if(_61[0]=="AUTHORIZED"){
var _62=_61[1].split(":");
if(_62[0]=="ticket"){
var _63=_62[1];
var _64=_63.split("|");
var _65=_64[0];
var _66=">|<"+_64[1];
_5d({"username":_65,"password":_66});
}
}
}
};
xhr.send(_5f.join("\n"));
};
function _sealAndAuthorize(_67,_68,_69,_6a,_6b){
var xhr=_67._getXHR("seal");
xhr.open("POST",_67._location,true);
xhr.onreadystatechange=function(){
if(xhr.readyState==4&&xhr.status==200){
var _6d=xhr.responseText.split("\n");
if(_6d[0]=="SEALED"){
var _6e=_6d[1].split(":");
if(_6e[0]=="value"){
var _6f=_6e[1];
_67._storage[_69]=_6f;
_authorize(_67,_6f,_6a,_6b);
}
}
}
};
xhr.send("SEAL\nvalue:"+_68+"\n\n");
};
function _singleSignOn(_70){
_70({username:"${http.username}",password:"${http.password}"});
};
return EncryptedKeyring;
})();
