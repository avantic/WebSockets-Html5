/**
 * Copyright (c) 2007-2011, Kaazing Corporation. All rights reserved.
 */

package com.kaazing.gateway.server.core.demo.data.udp;

import java.io.File;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.URI;
import java.security.SecureRandom;
import java.util.Random;

import org.apache.log4j.xml.DOMConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UdpDataSource {

	private static final String LOG4J_CONFIG_PROPERTY = "LOG4J_CONFIG";

	private static final Logger LOGGER = LoggerFactory.getLogger(UdpDataSource.class);

	/**
	 * @param args
	 */
	public static void main(String... args) throws Exception {
		String remoteURL = (args.length > 0) ? args[0] : "udp://localhost:50505";

		String log4jConfigProperty = System.getProperty(LOG4J_CONFIG_PROPERTY);
		if (log4jConfigProperty != null) {
			File log4jConfigFile = new File(log4jConfigProperty);
			DOMConfigurator.configure(log4jConfigFile.toURI().toURL());
		}

		URI remoteURI = URI.create(remoteURL);
		SocketAddress remoteAddress = new InetSocketAddress(remoteURI.getHost(), remoteURI.getPort());

		System.out.println("Sending UDP data to " + remoteURL);

		DatagramSocket socket = new DatagramSocket();
		Random random = new SecureRandom();
		while (true) {
			String data = STORIES[random.nextInt(STORIES.length)];
			byte[] buf = data.getBytes();
			DatagramPacket packet = new DatagramPacket(buf, buf.length, remoteAddress);
			socket.send(packet);
			LOGGER.debug("Sending UDP data: " + data);
			Thread.sleep(2000L);
		}
	}

	private static final String[] STORIES = new String[] {
		"Ranking the top 25 players in baseball",
		"Spacecraft blasts off in search of 'Earths'",
		"Ancient marvels, sun-splashed islands of Greece",
		"Why we're sleeping less",
		"Unemployed place their bets on casino jobs",
		"Crews save homes from wildfire",
		"Spare us, say bowlers to planned tax",
		"Proof of ancient Malaysian civilization found",
		"Papua New Guinea gets first conservation area",
		"Nation's rappers down to last two samples"
	};
}
