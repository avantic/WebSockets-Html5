/**
 * Copyright (c) 2007-2011, Kaazing Corporation. All rights reserved.
 */

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Resources;
using System.Text;
using System.Windows.Forms;

using com.kaazing.gateway.client.html5;

namespace com.kaazing.gateway.client.core.demo
{
    /// <summary>
    /// .Net Core Demo Main Page
    /// </summary>
    public partial class CoreDemoForm : Form
    {
        private WebSocket webSocket = null;

        private delegate void InvokeDelegate();

        /// <summary>
        /// .Net Core Demo Form
        /// </summary>
        public CoreDemoForm()
        {
            InitializeComponent();

            String defaultLocation = "ws://localhost:8001/echo";
            LocationText.Text = defaultLocation;

            ResourceManager resourceManager = new ResourceManager ("com.kaazing.gateway.client.core.demo.CoreDemoForm", GetType().Assembly);
            this.Icon = (Icon)resourceManager.GetObject("Favicon.Ico");

            //Logger.LoggerCallback = HandleLog;
        }

        private void CoreDemoForm_Load(object sender, EventArgs e)
        {
        }

        private void HandleLog(String message)
        {
            this.BeginInvoke((InvokeDelegate)(() =>
            {
                Log("LOG: " + message);
            }));
        }

        /*
         *  Button click handlers
         */

        private void ConnectButton_Click(object sender, EventArgs e)
        {
            // Immediately disable the connect button
            ConnectButton.Enabled = false;

            webSocket = new WebSocket();
            Log("CONNECT:" + LocationText.Text);

            webSocket.OpenEvent += new OpenEventHandler(OpenHandler);
            webSocket.CloseEvent += new CloseEventHandler(CloseHandler);
            webSocket.MessageEvent += new MessageEventHandler(MessageHandler);

            webSocket.Connect(LocationText.Text);
        }

        private void DisconnectButton_Click(object sender, EventArgs e)
        {
            Log("DISCONNECT");
            webSocket.Close();
        }

        private void SendButton_Click(object sender, EventArgs e)
        {
            Log("SEND:" + MessageText.Text);
            webSocket.Send(MessageText.Text);
        }

        /*
         * Console output 
         */
        private const int LOG_LIMIT = 50;
        private Queue<string> logLines = new Queue<string>();
        private void Log(string arg)
        {
            logLines.Enqueue(arg);
            if (logLines.Count > LOG_LIMIT)
            {
                logLines.Dequeue();
            }
            string[] o = logLines.ToArray<string>();

            o = o.Reverse<string>().ToArray<string>();

            Output.Text = string.Join("\r\n", o);
        }

        private void ClearLogButton_Click(object sender, EventArgs e)
        {
            logLines.Clear();
            Output.Text = "";
        }


        /*
         * Core Event Handlers
         */
        private void OpenHandler(object sender, OpenEventArgs args)
        {
            this.BeginInvoke((InvokeDelegate)(() =>
            {
                Log("CONNECTED");

                DisconnectButton.Enabled = true;
                SendButton.Enabled = true;
            }));
        }

        private void CloseHandler(object sender, CloseEventArgs args)
        {
            this.BeginInvoke((InvokeDelegate)(() =>
            {
                Log("DISCONNECTED");

                ConnectButton.Enabled = true;
                DisconnectButton.Enabled = false;
                SendButton.Enabled = false;
            }));
        }

        private void MessageHandler(object sender, MessageEventArgs args)
        {
            this.BeginInvoke((InvokeDelegate)(() =>
            {
                Log("MESSAGE: " + args.Data);
            }));
        }
    }
}
