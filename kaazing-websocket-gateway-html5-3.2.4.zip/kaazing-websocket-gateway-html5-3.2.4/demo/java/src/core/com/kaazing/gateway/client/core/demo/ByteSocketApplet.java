/**
 * Copyright (c) 2007-2011, Kaazing Corporation. All rights reserved.
 */

package com.kaazing.gateway.client.core.demo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URI;
import java.net.URL;

import javax.swing.DefaultListModel;
import javax.swing.GroupLayout;
import javax.swing.JApplet;
import javax.swing.JList;

import com.kaazing.gateway.client.html5.ByteBuffer;
import com.kaazing.gateway.client.html5.ByteSocket;
import com.kaazing.gateway.client.html5.ByteSocketAdapter;
import com.kaazing.gateway.client.html5.ByteSocketEvent;

public class ByteSocketApplet extends JApplet {

    private static final long serialVersionUID = 7149641265696836030L;

    private ByteSocket byteSocket;

    private static final int LIST_SIZE = 15;
    private javax.swing.JButton connect;
    private javax.swing.JButton close;
    private javax.swing.JButton send;
    private javax.swing.JTextField location;
    private javax.swing.JTextField message;
    private JList logList;
    private javax.swing.JButton clear;
    private DefaultListModel logModel;

    private javax.swing.JLabel locationLabel;
    private javax.swing.JLabel introLabel;
    private javax.swing.JLabel messageLabel;
    private javax.swing.JLabel logLabel;
    private javax.swing.JPanel connectPanel;
    private javax.swing.JPanel messagePanel;

    public void start() {
        logModel = new DefaultListModel();
        Container p = this.getContentPane();
        p.removeAll();
        p.setLayout(new BorderLayout());

        ByteSocketPanel byteSocketPanel = new ByteSocketPanel();
        connect.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    byteSocket.connect(new URI(location.getText()));
                } catch (Exception e1) {
                    e1.printStackTrace();
                    log(e1.getMessage());
                }
            }

        });

        close.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
		log("CLOSE");
                try {
                    byteSocket.close();
                } catch (Exception e1) {
                    e1.printStackTrace();
                    log(e1.getMessage());
                }
            }
        });

        send.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    ByteBuffer payload = ByteBuffer.wrap(message.getText().getBytes());
                    log("SEND:" + payload.getHexDump());
                    byteSocket.send(payload);
                } catch (Exception e1) {
                    e1.printStackTrace();
                    log(e1.getMessage());
                }
            }
        });

        clear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logModel.clear();
            }
        });
        p.add(byteSocketPanel, BorderLayout.CENTER);

        URL documentUrl = getDocumentBase();
        String locationUrl = "";
        boolean secure = false;
        if (documentUrl.getProtocol().equalsIgnoreCase("https")) {
            locationUrl = "wss://";
            secure = true;
        } else {
            locationUrl = "ws://";
        }
        int port = secure ? 9001 : 8001;
        String host = documentUrl.getHost();
        if (host == null || host.isEmpty()) {
            locationUrl += "localhost:" + port;
        } else {
            locationUrl += documentUrl.getHost() + ":" + port;
        }
        location.setText(locationUrl + "/echo");

        logModel.setSize(LIST_SIZE);

        try {
            byteSocket = new ByteSocket();
        } catch (Exception e) {
            e.printStackTrace();
            log(e.getMessage());
        }

        byteSocket.addByteSocketListener(new ByteSocketAdapter() {

            @Override
            public void onClose(ByteSocketEvent closedEvent) {
                updateButtonsForClosed();
                log("DISCONNECTED");
            }

            @Override
            public void onMessage(ByteSocketEvent messageEvent) {
                log("RESPONSE:" + messageEvent.getData().getHexDump());
            }

            @Override
            public void onOpen(ByteSocketEvent openEvent) {
                updateButtonsForConnected();
                log("CONNECTED");
            }

        });
        updateButtonsForClosed();
    }

    @Override
    public void stop() {
        if (byteSocket != null) {
            try {
                byteSocket.close();
            } catch (Exception e) {
            }
        }
    }

    private synchronized void log(String str) {
        logModel.add(0, str);
        if (logModel.getSize() > LIST_SIZE) {
            logModel.removeElementAt(LIST_SIZE);
        }
    }

    private void updateButtonsForClosed() {
        connect.setEnabled(true);
        close.setEnabled(false);
        send.setEnabled(false);
    }

    private void updateButtonsForConnected() {
        connect.setEnabled(false);
        close.setEnabled(true);
        send.setEnabled(true);
    }

    public class ByteSocketPanel extends javax.swing.JPanel {

        private static final long serialVersionUID = 5461921642310580530L;

        public ByteSocketPanel() {
            initComponents();
        }

        private void initComponents() {

            connectPanel = new javax.swing.JPanel();
            locationLabel = new javax.swing.JLabel();
            location = new javax.swing.JTextField();
            connect = new javax.swing.JButton();
            close = new javax.swing.JButton();
            introLabel = new javax.swing.JLabel();
            messagePanel = new javax.swing.JPanel();
            messageLabel = new javax.swing.JLabel();
            message = new javax.swing.JTextField();
            send = new javax.swing.JButton();
            logLabel = new javax.swing.JLabel();
            logList = new JList(logModel);
            clear = new javax.swing.JButton();

            setBackground(Color.WHITE);
            connectPanel.setBackground(Color.WHITE);
            messagePanel.setBackground(Color.WHITE);

            Color blueText = new Color(0x3C708F);

            setBorder(javax.swing.BorderFactory.createTitledBorder(null, "ByteSocket Demo",
                    javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION,
                    new java.awt.Font("Dialog", 1, 12))); // NOI18N
            setRequestFocusEnabled(false);

            introLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
            introLabel
                    .setText("<html>This is a demo of an echo server client that uses ByteSocket to send text messages to the Kaazing Gateway Echo service, <br>which echoes back the messages.</html>");
            introLabel.setForeground(blueText);

            connectPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
            connectPanel.setPreferredSize(new java.awt.Dimension(400, 75));

            locationLabel.setText("Location:");
            locationLabel.setToolTipText("Enter ByteSocket Location");

            location.setText("ws://localhost:8001/echo");
            location.setToolTipText("Enter the location of the ByteSocket");
            location.setColumns(25);

            connect.setText("Connect");
            connect.setToolTipText("Connect to ByteSocket");
            connect.setName("connect");

            close.setText("Close");
            close.setToolTipText("Close the ByteSocket");
            close.setName("close");

            FlowLayout panel1Layout = new FlowLayout(FlowLayout.LEADING, 10, 10);
            connectPanel.setLayout(panel1Layout);
            connectPanel.add(locationLabel);
            connectPanel.add(location);
            connectPanel.add(connect);
            connectPanel.add(close);

            messagePanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "",
                    javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.ABOVE_TOP));

            messageLabel.setText("Message:");
            messageLabel.setToolTipText("Message");

            message.setText("Hello, ByteSocket!");
            message.setToolTipText("Enter message for ByteSocket");
            message.setColumns(25);

            send.setText("Send");
            send.setToolTipText("Send message to ByteSocket");
            send.setName("send");

            FlowLayout panel2Layout = new FlowLayout(FlowLayout.LEADING, 10, 10);
            messagePanel.setLayout(panel2Layout);
            messagePanel.add(messageLabel);
            messagePanel.add(message);
            messagePanel.add(send);

            logLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
            logLabel.setText("Log messages");
            logLabel.setPreferredSize(new java.awt.Dimension(0, 0));
            logLabel.setForeground(blueText);

            logList.setName("log");

            clear.setText("Clear");
            clear.setToolTipText("Send message to ByteSocket");
            clear.setName("clear");

            GroupLayout layout = new GroupLayout(this);
            layout.setAutoCreateGaps(true);
            layout.setAutoCreateContainerGaps(true);
            this.setLayout(layout);
            layout.setHorizontalGroup(layout.createParallelGroup().addComponent(introLabel).addComponent(connectPanel)
                    .addComponent(messagePanel).addComponent(logLabel).addComponent(logList).addComponent(clear));
            layout.setVerticalGroup(layout.createSequentialGroup().addComponent(introLabel).addComponent(connectPanel,
                    GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE).addComponent(
                    messagePanel, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(logLabel).addComponent(logList, 300, 300, 300).addComponent(clear));

        }// </editor-fold>

    }

}