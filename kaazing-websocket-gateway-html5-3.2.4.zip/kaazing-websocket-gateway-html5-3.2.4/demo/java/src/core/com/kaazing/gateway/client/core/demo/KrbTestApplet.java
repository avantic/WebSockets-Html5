/**
 * Copyright (c) 2007-2011, Kaazing Corporation. All rights reserved.
 */

package com.kaazing.gateway.client.core.demo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.PasswordAuthentication;
import java.net.URI;
import java.net.URL;

import javax.swing.DefaultListModel;
import javax.swing.GroupLayout;
import javax.swing.JApplet;
import javax.swing.JList;

import com.kaazing.gateway.client.html5.WebSocketDefaults;
import com.kaazing.gateway.client.html5.auth.LoginHandler;
import com.kaazing.gateway.client.security.kerberos.kerberos5.Krb5Client;
import com.kaazing.gateway.client.security.kerberos.kerberos5.Krb5ClientListener;
import com.kaazing.gateway.client.security.kerberos.kerberos5.event.Krb5ClientEvent;
import com.kaazing.gateway.client.security.kerberos.kerberos5.event.Krb5ErrorEvent;
import com.kaazing.gateway.client.security.kerberos.kerberos5.event.Krb5TokenEvent;
import com.kaazing.gateway.client.security.kerberos.kerberos5.state.LocationContext;

public class KrbTestApplet extends JApplet {

    private static final long serialVersionUID = -4144542608007277085L;

    private Krb5Client client;

    private static final int LIST_SIZE = 15;
    private javax.swing.JButton connect;
    private javax.swing.JButton close;
    private javax.swing.JButton send;
    private javax.swing.JTextField location;
    private javax.swing.JTextField spn;
    private JList logList;
    private javax.swing.JButton clear;
    private DefaultListModel logModel;

    private javax.swing.JLabel locationLabel;
    private javax.swing.JLabel introLabel;
    private javax.swing.JLabel messageLabel;
    private javax.swing.JLabel logLabel;
    private javax.swing.JPanel connectPanel;
    private javax.swing.JPanel messagePanel;

    public void start() {
        logModel = new DefaultListModel();
        Container p = this.getContentPane();
        p.removeAll();
        p.setLayout(new BorderLayout());

        KrbTestPanel krbTestPanel = new KrbTestPanel();
        final LoginHandler loginHandler = new LoginHandler() {
            private String username;
            private char[] password;

            @Override
            public PasswordAuthentication getCredentials() {
                try {
                    LoginDialog dialog = new LoginDialog(Frame.getFrames()[0]);
                    username = dialog.getUsername();
                    password = dialog.getPassword();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return new PasswordAuthentication(username, password);
            }
        };

        connect.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String locationText = location.getText();
                    String locStr = locationText;
                    int index = locStr.indexOf("://");
                    if (index != -1) {
                        locStr = locStr.substring(index + 3);
                        index = locStr.indexOf("/");
                        if (index != -1) {
                            locStr = locStr.substring(0, index);
                            WebSocketDefaults.setLoginHandlerForLocation(locStr, loginHandler);
                        }
                    }
                    LocationContext locationContext = new LocationContext();
                    locationContext.setDefaultLocation(new URI(locationText));
                    client.setLocationContext(locationContext);
                    client.connect(new URI(locationText), new com.kaazing.gateway.client.security.LoginHandler() {
                                @Override
                                public PasswordAuthentication getCredentials() {
                                    return loginHandler.getCredentials();
                                }
                            });
                } catch (Exception e1) {
                    e1.printStackTrace();
                    log(e1.getMessage());
                }
            }

        });

        close.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    client.disconnect();
                    log("CLOSE");
                } catch (Exception e1) {
                    e1.printStackTrace();
                    log(e1.getMessage());
                }
            }
        });

        send.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                log("REQUEST GSS TOKEN:" + spn.getText());
                client.requestGssToken(spn.getText());
            }
        });

        clear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logModel.clear();
            }
        });
        p.add(krbTestPanel, BorderLayout.CENTER);

        URL documentUrl = getDocumentBase();
        String locationUrl = "";
        boolean secure = false;
        if (documentUrl.getProtocol().equalsIgnoreCase("https")) {
            locationUrl = "wss://";
            secure = true;
        } else {
            locationUrl = "ws://";
        }
        int port = secure ? 9000 : 8000;
        String host = documentUrl.getHost();
        if (host == null || host.isEmpty()) {
            locationUrl += "localhost:" + port;
        } else {
            locationUrl += documentUrl.getHost() + ":" + port;
        }
        location.setText(locationUrl + "/kerberos5");

        logModel.setSize(LIST_SIZE);

        try {
            client = new Krb5Client();
        } catch (Exception e) {
            e.printStackTrace();
            log(e.getMessage());
        }

        client.addClientListener(new Krb5ClientListener() {

            @Override
            public void onClose(Krb5ClientEvent closeEvent) {
                updateButtonsForClosed();
                log("CLOSE");
            }

            @Override
            public void onError(Krb5ErrorEvent errorEvent) {
                log("ERROR: " + errorEvent.getMessageText());
            }

            @Override
            public void onOpen(Krb5ClientEvent openEvent) {
                updateButtonsForConnected();
                log("CONNECTED");
            }

            @Override
            public void onToken(Krb5TokenEvent tokenEvent) {
                log("TOKEN");
                log(tokenEvent.getToken());
            }

        });
        updateButtonsForClosed();
    }

    @Override
    public void stop() {
        if (client != null) {
            try {
                client.disconnect();
            } catch (Exception e) {
            }
        }
    }

    private synchronized void log(String str) {
        logModel.add(0, str);
        if (logModel.getSize() > LIST_SIZE) {
            logModel.removeElementAt(LIST_SIZE);
        }
    }

    private void updateButtonsForClosed() {
        connect.setEnabled(true);
        close.setEnabled(false);
        send.setEnabled(false);
    }

    private void updateButtonsForConnected() {
        connect.setEnabled(false);
        close.setEnabled(true);
        send.setEnabled(true);
    }

    public class KrbTestPanel extends javax.swing.JPanel {

        private static final long serialVersionUID = 3746311222633713218L;

        public KrbTestPanel() {
            initComponents();
        }

        private void initComponents() {

            connectPanel = new javax.swing.JPanel();
            locationLabel = new javax.swing.JLabel();
            location = new javax.swing.JTextField();
            connect = new javax.swing.JButton();
            close = new javax.swing.JButton();
            introLabel = new javax.swing.JLabel();
            messagePanel = new javax.swing.JPanel();
            messageLabel = new javax.swing.JLabel();
            spn = new javax.swing.JTextField();
            send = new javax.swing.JButton();
            logLabel = new javax.swing.JLabel();
            logList = new JList(logModel);
            clear = new javax.swing.JButton();

            setBackground(Color.WHITE);
            connectPanel.setBackground(Color.WHITE);
            messagePanel.setBackground(Color.WHITE);

            Color blueText = new Color(0x3C708F);

            setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Kerberos Client Test",
                    javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION,
                    new java.awt.Font("Dialog", 1, 12))); // NOI18N
            setRequestFocusEnabled(false);

            introLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
            introLabel.setText("<html>This is a test applet for the Kerberos client.</html>");
            introLabel.setForeground(blueText);

            connectPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
            connectPanel.setPreferredSize(new java.awt.Dimension(400, 75));

            locationLabel.setText("Location:");
            locationLabel.setToolTipText("Enter Kerberos Service Location");

            location.setText("ws://localhost:8000/kerberos5");
            location.setToolTipText("Enter the location of the Kerberos v5 service");
            location.setColumns(25);

            connect.setText("Connect");
            connect.setToolTipText("Connect to service");
            connect.setName("connect");

            close.setText("Close");
            close.setToolTipText("Close the connection");
            close.setName("close");

            FlowLayout panel1Layout = new FlowLayout(FlowLayout.LEADING, 10, 10);
            connectPanel.setLayout(panel1Layout);
            connectPanel.add(locationLabel);
            connectPanel.add(location);
            connectPanel.add(connect);
            connectPanel.add(close);

            messagePanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "",
                    javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.ABOVE_TOP));

            messageLabel.setText("SPN:");
            messageLabel.setToolTipText("Service Principal Name");

            spn.setText("HTTP/localhost");
            spn.setToolTipText("Enter the SPN");
            spn.setColumns(25);

            send.setText("Request GSS Token");
            send.setToolTipText("Request token");
            send.setName("send");

            FlowLayout panel2Layout = new FlowLayout(FlowLayout.LEADING, 10, 10);
            messagePanel.setLayout(panel2Layout);
            messagePanel.add(messageLabel);
            messagePanel.add(spn);
            messagePanel.add(send);

            logLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
            logLabel.setText("Log messages");
            logLabel.setPreferredSize(new java.awt.Dimension(0, 0));
            logLabel.setForeground(blueText);

            logList.setName("log");

            clear.setText("Clear");
            clear.setToolTipText("Send message to WebSocket");
            clear.setName("clear");

            GroupLayout layout = new GroupLayout(this);
            layout.setAutoCreateGaps(true);
            layout.setAutoCreateContainerGaps(true);
            this.setLayout(layout);
            layout.setHorizontalGroup(layout.createParallelGroup().addComponent(introLabel).addComponent(connectPanel)
                    .addComponent(messagePanel).addComponent(logLabel).addComponent(logList).addComponent(clear));
            layout.setVerticalGroup(layout.createSequentialGroup().addComponent(introLabel).addComponent(connectPanel,
                    GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE).addComponent(
                    messagePanel, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(logLabel).addComponent(logList, 300, 300, 300).addComponent(clear));

        }// </editor-fold>

    }

}
