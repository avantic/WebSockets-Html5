/**
 * Copyright (c) 2007-2011, Kaazing Corporation. All rights reserved.
 */

package com.kaazing.gateway.client.core.demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.BoxLayout;
import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import com.kaazing.gateway.client.html5.EventSource;
import com.kaazing.gateway.client.html5.EventSourceAdapter;
import com.kaazing.gateway.client.html5.EventSourceEvent;

@SuppressWarnings("serial")
public class ServerSentEventsApplet extends JApplet implements ActionListener {

    private static final long serialVersionUID = 3412240189439244444L;
    JTextField url = new JTextField(30);
    JButton addSse = new JButton("Create Sse");
    JButton closeSse = new JButton("Stop Sse");
    EventSource es = new EventSource();
    JButton clear = new JButton("Clear");
    JLabel logArea = new JLabel() {
        public Dimension getPreferredSize() {
            return new Dimension(400, 400);
        }

        public Dimension getMinimumSize() {
            return new Dimension(400, 200);
        }

        public Dimension getMaximumSize() {
            return new Dimension(400, 800);
        }
    };

    public void init() {
        setBackground(Color.WHITE);
        setLayout(new BoxLayout(this.getContentPane(), BoxLayout.PAGE_AXIS));
        JPanel p = new JPanel();
        p.setLayout(new FlowLayout());
        p.add(new JLabel("Enter WS URL:"));
        p.add(url);

        URL documentUrl = getDocumentBase();
        String locationUrl = documentUrl.getProtocol() + "://" + documentUrl.getHost() + ":" + 
                             documentUrl.getPort();
        url.setText(locationUrl + "/sse");

        JPanel p1 = new JPanel();
        p1.setLayout(new FlowLayout());
        p1.add(addSse);
        p1.add(closeSse);
        p1.add(clear);
        JPanel p2 = new JPanel();
        p2.setLayout(new FlowLayout());
        p2.add(logArea);
        addSse.addActionListener(this);
        closeSse.addActionListener(this);
        clear.addActionListener(this);
        closeSse.setEnabled(false);
        this.getContentPane().add(p);
        this.getContentPane().add(p1);
        this.getContentPane().add(p2);
        es.addEventSourceListener(new EventSourceAdapter() {

            @Override
            public void onError(EventSourceEvent error) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        logArea.setText("SSE Error");
                    }
                });
            }

            @Override
            public void onMessage(final EventSourceEvent message) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        logArea.setText("<html>" + message.getData() + "</html>");
                    }
                });
            }

            @Override
            public void onOpen(EventSourceEvent open) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        logArea.setText("SSE Opened");
                    }
                });
            }

        });
    }

    public void actionPerformed(ActionEvent arg0) {
        try {
            if (arg0.getSource() == addSse) {
                String wsUrl = url.getText();
                es.connect(wsUrl);
                addSse.setEnabled(false);
                closeSse.setEnabled(true);
            } else if (arg0.getSource() == clear) {
                logArea.setText("");
            } else {
                es.disconnect();
                addSse.setEnabled(true);
                closeSse.setEnabled(false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
